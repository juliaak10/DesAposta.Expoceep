# -*- coding: utf-8 -*-
"""
Arquivo: backend/app.py
PROJETO: CEEP Contra as BETS - Petição Pública
Equipe: Gabriely Martins Cabral, Julia Augusta do Espírito Santo Nicolack e Rafael Bertoldo Varela
Turma: 3M - Desenvolvimento de Sistemas
Tema: Plataforma Informativa e Petição Pública contra Apostas Virtuais
"""

import os
import sqlite3
from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'bd', 'peticao.db')
SQL_SCRIPT_PATH = os.path.join(os.path.dirname(__file__), '..', 'bd', 'script.sql')

def get_db_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db():
    conn = get_db_connection()
    if os.path.exists(SQL_SCRIPT_PATH):
        with open(SQL_SCRIPT_PATH, 'r', encoding='utf-8') as f:
            conn.executescript(f.read())
    else:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS categorias (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome_alerta TEXT NOT NULL UNIQUE
            );
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS assinaturas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome_completo TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                cpf TEXT NOT NULL UNIQUE,
                comentario TEXT,
                data_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
                categoria_id INTEGER NOT NULL,
                FOREIGN KEY (categoria_id) REFERENCES categorias(id)
            );
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS pesquisa_respostas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                faixa_etaria TEXT NOT NULL,
                contato_apostas TEXT NOT NULL,
                proibicao_suficiente TEXT NOT NULL,
                area_prioritaria TEXT NOT NULL,
                criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
            );
        ''')
        conn.execute("INSERT OR IGNORE INTO categorias (id, nome_alerta) VALUES (1, 'Impacto Financeiro'), (2, 'Saúde Mental'), (3, 'Regulamentação');")
    conn.commit()
    conn.close()

# Rota Principal exigida no Guia de Execução (Item 5 e Item 6 - Comprovação JSON)
@app.route('/', methods=['GET'])
def status_api():
    return jsonify({
        "projeto": "CEEP Contra as BETS - Petição Pública",
        "status": "API Back-End rodando com sucesso na Etapa 1!",
        "versao": "1.0"
    }), 200

# Rota para listar as Categorias de Alerta (1:N)
@app.route('/api/categorias', methods=['GET'])
def listar_categorias():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, nome_alerta FROM categorias ORDER BY id ASC')
    linhas = cursor.fetchall()
    categorias = [{"id": row["id"], "nome_alerta": row["nome_alerta"]} for row in linhas]
    conn.close()
    return jsonify({"categorias": categorias}), 200

# Rota para listar assinaturas e estatísticas da petição
@app.route('/api/assinaturas', methods=['GET'])
def listar_assinaturas():
    conn = get_db_connection()
    cursor = conn.cursor()
    query = '''
        SELECT 
            a.id, 
            a.nome_completo, 
            a.email, 
            a.cpf, 
            a.comentario, 
            a.data_registro, 
            a.categoria_id,
            c.nome_alerta as categoria_nome
        FROM assinaturas a
        JOIN categorias c ON a.categoria_id = c.id
        ORDER BY a.id DESC
    '''
    cursor.execute(query)
    linhas = cursor.fetchall()
    
    # Anonimizar dados sensíveis para exibição pública segura
    assinaturas = []
    for row in linhas:
        partes_nome = row["nome_completo"].strip().split()
        nome_publico = partes_nome[0] + (" " + partes_nome[-1][0] + "." if len(partes_nome) > 1 else "")
        cpf_mascarado = "***." + row["cpf"][4:7] + ".***-**" if len(row["cpf"]) >= 11 else "***"
        
        assinaturas.append({
            "id": row["id"],
            "nome_completo": row["nome_completo"],
            "nome_publico": nome_publico,
            "cpf_mascarado": cpf_mascarado,
            "comentario": row["comentario"],
            "data_registro": row["data_registro"],
            "categoria_id": row["categoria_id"],
            "categoria_nome": row["categoria_nome"]
        })
    
    # Estatísticas por categoria (Regra 1:N)
    cursor.execute('''
        SELECT c.id, c.nome_alerta, COUNT(a.id) as total
        FROM categorias c
        LEFT JOIN assinaturas a ON c.id = a.categoria_id
        GROUP BY c.id, c.nome_alerta
        ORDER BY total DESC
    ''')
    stats = [{"categoria_id": r["id"], "nome_alerta": r["nome_alerta"], "total": r["total"]} for r in cursor.fetchall()]
    
    conn.close()
    return jsonify({
        "total": len(assinaturas),
        "assinaturas": assinaturas,
        "estatisticas": stats
    }), 200

# Rota para registrar uma nova assinatura (com validações de unicidade e integridade)
@app.route('/api/assinaturas', methods=['POST'])
@app.route('/salvar.php', methods=['POST'])
def salvar_assinatura():
    # Aceita tanto JSON quanto FormData tradicional do formulário
    dados = request.get_json(silent=True) or request.form.to_dict()
    
    nome = (dados.get('nomeCompleto') or dados.get('nome_completo') or '').strip()
    email = (dados.get('email') or '').strip().lower()
    cpf = (dados.get('cpf') or '').strip()
    categoria_id = dados.get('categoria_id') or dados.get('categoriaId')
    comentario = (dados.get('comentario') or '').strip()

    # Validações básicas
    if not nome or not email or not cpf or not categoria_id:
        return jsonify({
            "sucesso": False,
            "mensagem": "Campos obrigatórios incompletos: nome completo, e-mail, CPF e categoria são obrigatórios."
        }), 400

    # Limpeza simples de pontuação de CPF
    cpf_limpo = ''.join(filter(str.isdigit, cpf))
    if len(cpf_limpo) != 11:
        return jsonify({
            "sucesso": False,
            "mensagem": "CPF inválido. O CPF deve conter 11 dígitos numéricos."
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute('''
            INSERT INTO assinaturas (nome_completo, email, cpf, comentario, categoria_id)
            VALUES (?, ?, ?, ?, ?)
        ''', (nome, email, cpf, comentario if comentario else None, int(categoria_id)))
        conn.commit()
        novo_id = cursor.lastrowid
        conn.close()
        return jsonify({
            "sucesso": True,
            "mensagem": "Assinatura registrada com sucesso no banco de dados!",
            "id": novo_id
        }), 201
    except sqlite3.IntegrityError as e:
        conn.close()
        msg = str(e).lower()
        if 'email' in msg:
            return jsonify({"sucesso": False, "mensagem": "Este e-mail já registrou uma assinatura na petição."}), 409
        elif 'cpf' in msg:
            return jsonify({"sucesso": False, "mensagem": "Este CPF já foi cadastrado na petição pública."}), 409
        elif 'foreign key' in msg:
            return jsonify({"sucesso": False, "mensagem": "Categoria de alerta informada não é válida."}), 400
        else:
            return jsonify({"sucesso": False, "mensagem": f"Erro de integridade no banco de dados: {str(e)}"}), 400
    except Exception as e:
        conn.close()
        return jsonify({"sucesso": False, "mensagem": f"Erro interno ao salvar assinatura: {str(e)}"}), 500

# Rota para a Pesquisa Científica ExpoCEEP
@app.route('/api/pesquisa', methods=['GET', 'POST'])
def rota_pesquisa():
    if request.method == 'GET':
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id, faixa_etaria, contato_apostas, proibicao_suficiente, area_prioritaria, criado_em FROM pesquisa_respostas ORDER BY id DESC')
        rows = cursor.fetchall()
        
        total = len(rows)
        por_faixa = {}
        por_contato = {}
        por_proibicao = {}
        por_area = {}
        recentes = []

        for i, r in enumerate(rows):
            faixa = r['faixa_etaria']
            contato = r['contato_apostas']
            proib = r['proibicao_suficiente']
            area = r['area_prioritaria']
            
            por_faixa[faixa] = por_faixa.get(faixa, 0) + 1
            por_contato[contato] = por_contato.get(contato, 0) + 1
            por_proibicao[proib] = por_proibicao.get(proib, 0) + 1
            por_area[area] = por_area.get(area, 0) + 1
            
            if i < 10:
                recentes.append({
                    "id": r['id'],
                    "faixa_etaria": faixa,
                    "contato_apostas": contato,
                    "proibicao_suficiente": proib,
                    "area_prioritaria": area,
                    "criado_em": r['criado_em']
                })
        
        conn.close()
        return jsonify({
            "total": total,
            "porFaixaEtaria": por_faixa,
            "porContato": por_contato,
            "porProibicao": por_proibicao,
            "porAreaPrioritaria": por_area,
            "respostasRecentes": recentes
        }), 200

    elif request.method == 'POST':
        dados = request.get_json(silent=True) or request.form.to_dict()
        faixa = (dados.get('faixa_etaria') or '').strip()
        contato = (dados.get('contato_apostas') or '').strip()
        proibicao = (dados.get('proibicao_suficiente') or '').strip()
        area = (dados.get('area_prioritaria') or '').strip()

        if not faixa or not contato or not proibicao or not area:
            return jsonify({"sucesso": False, "mensagem": "Responda a todas as 4 perguntas da pesquisa."}), 400

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO pesquisa_respostas (faixa_etaria, contato_apostas, proibicao_suficiente, area_prioritaria)
            VALUES (?, ?, ?, ?)
        ''', (faixa, contato, proibicao, area))
        conn.commit()
        novo_id = cursor.lastrowid
        conn.close()

        return jsonify({
            "sucesso": True,
            "mensagem": "Sua resposta foi registrada no banco de dados SQLite com sucesso!",
            "id": novo_id
        }), 201

if __name__ == '__main__':
    init_db()
    print("Iniciando API CEEP Contra as BETS...")
    app.run(debug=True, host='0.0.0.0', port=5000)
