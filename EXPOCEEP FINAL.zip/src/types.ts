export interface Categoria {
  id: number;
  nome_alerta: string;
}

export interface Assinatura {
  id: number;
  nome_completo: string;
  nome_publico?: string;
  email: string;
  cpf: string;
  cpf_mascarado?: string;
  comentario: string | null;
  data_registro: string;
  categoria_id: number;
  categoria_nome?: string;
}

export interface EstatisticaCategoria {
  categoria_id: number;
  nome_alerta: string;
  total: number;
  porcentagem: number;
}

export interface AssinaturaFormData {
  nomeCompleto: string;
  email: string;
  cpf: string;
  categoria_id: number | '';
  comentario: string;
}

export interface PesquisaResposta {
  id: number;
  faixa_etaria: string;
  contato_apostas: string;
  proibicao_suficiente: string;
  area_prioritaria: string;
  criado_em: string;
}

export interface PesquisaEstatisticas {
  total: number;
  porFaixaEtaria: Record<string, number>;
  porContato: Record<string, number>;
  porProibicao: Record<string, number>;
  porAreaPrioritaria: Record<string, number>;
  respostasRecentes: PesquisaResposta[];
}

export interface PesquisaFormData {
  faixa_etaria: string;
  contato_apostas: string;
  proibicao_suficiente: string;
  area_prioritaria: string;
}

export interface DbInspectionData {
  tables: Record<string, { columns: string[]; rows: any[][] }>;
  scriptSql: string;
  status: {
    online: boolean;
    dbEngine: string;
    storagePath: string;
    tablesCount: number;
  };
}

