import React from 'react';
import {
  GraduationCap,
  Code2,
  Database,
  Layers,
  FileCode,
  Download,
  Users,
  Award,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';

interface AboutProjectSectionProps {
  onOpenDatabase: () => void;
}

export const AboutProjectSection: React.FC<AboutProjectSectionProps> = ({ onOpenDatabase }) => {
  return (
    <section id="sobre" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#14171b] text-[#f4f1ea] border-b border-[#23272d]">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Cabeçalho */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-[#d8a13b]/15 text-[#d8a13b] border border-[#d8a13b]/30 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
            <GraduationCap className="w-3.5 h-3.5" />
            Ficha Acadêmica • TCC / ExpoCEEP
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight text-[#f4f1ea]">
            Sobre o Projeto:{' '}
            <span className="text-[#e4552e]">Brasil Contra as Bets</span>
          </h2>
          <p className="text-[#a9adb6] text-base sm:text-lg leading-relaxed">
            Desenvolvido por estudantes do Curso Técnico em Desenvolvimento de Sistemas, o projeto
            evoluiu de uma petição pública inicial para uma plataforma completa de conscientização social,
            simulação interativa, pesquisa sociológica e análise de dados em tempo real.
          </p>
        </div>

        {/* Informações da Equipe e Instituição */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Equipe */}
          <div className="bg-[#0e1013] border border-[#2b3038] rounded-3xl p-6 sm:p-7 space-y-4 shadow-lg">
            <div className="w-10 h-10 rounded-xl bg-[#e4552e]/20 text-[#e4552e] flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono text-[#d8a13b] uppercase font-bold block">
                Autores e Desenvolvedores
              </span>
              <h3 className="text-lg font-bold text-[#f4f1ea] uppercase mt-1">
                Equipe Turma 3M
              </h3>
            </div>
            <ul className="text-xs sm:text-sm text-[#c5c5c5] space-y-2">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#e4552e]"></span>
                Gabriely Martins Cabral
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#e4552e]"></span>
                Julia Augusta do Espírito Santo Nicolack
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#e4552e]"></span>
                Rafael Bertoldo Varela
              </li>
            </ul>
          </div>

          {/* Card 2: Instituição e Curso */}
          <div className="bg-[#0e1013] border border-[#2b3038] rounded-3xl p-6 sm:p-7 space-y-4 shadow-lg">
            <div className="w-10 h-10 rounded-xl bg-[#d8a13b]/20 text-[#d8a13b] flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono text-[#d8a13b] uppercase font-bold block">
                Instituição de Ensino
              </span>
              <h3 className="text-lg font-bold text-[#f4f1ea] uppercase mt-1">
                CEEP - ExpoCEEP
              </h3>
            </div>
            <div className="text-xs sm:text-sm text-[#a9adb6] space-y-1.5 leading-relaxed">
              <p>
                <strong>Curso:</strong> Técnico em Desenvolvimento de Sistemas
              </p>
              <p>
                <strong>Turma:</strong> 3M
              </p>
              <p>
                <strong>Evento:</strong> Exposição Tecnológica e Científica ExpoCEEP
              </p>
              <p>
                <strong>Tema Central:</strong> Da Proibição à Prevenção — O papel da tecnologia na conscientização contra apostas virtuais.
              </p>
            </div>
          </div>

          {/* Card 3: Arquitetura e Banco */}
          <div className="bg-[#0e1013] border border-[#2b3038] rounded-3xl p-6 sm:p-7 space-y-4 shadow-lg">
            <div className="w-10 h-10 rounded-xl bg-[#2e7d5b]/20 text-[#50fa7b] flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono text-[#50fa7b] uppercase font-bold block">
                Engenharia de Dados
              </span>
              <h3 className="text-lg font-bold text-[#f4f1ea] uppercase mt-1">
                SQLite 3 Relacional 1:N
              </h3>
            </div>
            <div className="text-xs text-[#a9adb6] space-y-2 leading-relaxed">
              <p>
                Armazenamento com chave estrangeira estrita entre <code className="text-[#d8a13b] font-mono">categorias</code> e <code className="text-[#d8a13b] font-mono">assinaturas</code>, mais tabela <code className="text-[#d8a13b] font-mono">pesquisa_respostas</code>.
              </p>
              <button
                onClick={onOpenDatabase}
                className="w-full mt-2 py-2 px-3 rounded-xl bg-[#1a1e24] hover:bg-[#252b33] text-[#d8a13b] border border-[#34373b] font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Layers className="w-3.5 h-3.5" />
                Inspecionar Tabelas & DER
              </button>
            </div>
          </div>
        </div>

        {/* Stack Tecnológica Detalhada */}
        <div className="bg-[#0e1013] border border-[#2b3038] rounded-3xl p-6 sm:p-10 space-y-6">
          <div className="flex items-center gap-3">
            <Code2 className="w-6 h-6 text-[#d8a13b]" />
            <h3 className="text-xl sm:text-2xl font-black uppercase text-[#f4f1ea]">
              Stack Tecnológica Preservada e Evoluída
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="p-4 bg-[#14171b] rounded-2xl border border-[#23272d] space-y-1.5">
              <span className="font-extrabold uppercase text-[#e4552e]">Frontend</span>
              <p className="text-[#c5c5c5]">
                React 19, TypeScript, Vite, Tailwind CSS v4, Lucide React, Motion.
              </p>
            </div>

            <div className="p-4 bg-[#14171b] rounded-2xl border border-[#23272d] space-y-1.5">
              <span className="font-extrabold uppercase text-[#d8a13b]">Backend Node</span>
              <p className="text-[#c5c5c5]">
                Express com TypeScript, tsx, middleware unificado, API RESTful JSON e fallback salvar.php.
              </p>
            </div>

            <div className="p-4 bg-[#14171b] rounded-2xl border border-[#23272d] space-y-1.5">
              <span className="font-extrabold uppercase text-[#50fa7b]">Banco de Dados</span>
              <p className="text-[#c5c5c5]">
                SQLite 3 via WebAssembly Engine (sql.js), bd/script.sql DDL, bd/peticao.db em disco.
              </p>
            </div>

            <div className="p-4 bg-[#14171b] rounded-2xl border border-[#23272d] space-y-1.5">
              <span className="font-extrabold uppercase text-[#8a8f99]">Backend Python</span>
              <p className="text-[#c5c5c5]">
                Flask, Flask-CORS (backend/app.py) documentado para equivalência didática.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
