import React, { useState } from 'react';
import {
  Sparkles,
  TrendingDown,
  RotateCcw,
  AlertTriangle,
  Brain,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ChevronRight,
  Info,
} from 'lucide-react';

interface Rodada {
  numero: number;
  decisao: string;
  valorApostado: number;
  resultado: 'ganhou' | 'perdeu' | 'quase_ganhou';
  saldoApos: number;
  mensagem: string;
  conceitoExplicado: string;
  nomeConceito: string;
}

export const SimulatorSection: React.FC = () => {
  const [saldo, setSaldo] = useState<number>(100);
  const [historico, setHistorico] = useState<Rodada[]>([
    {
      numero: 0,
      decisao: 'Início da Simulação',
      valorApostado: 0,
      resultado: 'ganhou',
      saldoApos: 100,
      mensagem: 'Você recebeu R$ 100,00 fictícios para a simulação.',
      conceitoExplicado: 'Saldo inicial neutro para demonstrar o comportamento de risco.',
      nomeConceito: 'Ponto de Partida',
    },
  ]);
  const [rodadaAtual, setRodadaAtual] = useState<number>(1);
  const [finalizado, setFinalizado] = useState<boolean>(false);
  const [analiseExpandida, setAnaliseExpandida] = useState<boolean>(true);

  // Cenários educativos pré-configurados
  const cenarios = [
    {
      rodada: 1,
      titulo: 'Cenário 1: O "Grupo VIP do Telegram"',
      descricao:
        'Um influenciador promete uma aposta esportiva de "Odd 2.50 com 98% de assertividade e método infalível".',
      opcoes: [
        {
          rotulo: 'Apostar R$ 20,00 acreditando na dica do influencer',
          valor: 20,
          outcome: 'quase_ganhou' as const,
          variacao: -20,
          resultadoMsg:
            'O time vencia por 1 a 0 até os 48 do 2º tempo, mas sofreu o empate no último minuto. Você PERDEU R$ 20,00.',
          conceito: 'Efeito Quase-Vitória (Near-Miss)',
          explicacao:
            'A sensação de que "bateu na trave" estimula seu cérebro a liberar tanta dopamina quanto se tivesse ganho, induzindo você a apostar de novo para "acertar na próxima".',
        },
        {
          rotulo: 'Apostar R$ 10,00 com cautela para testar',
          valor: 10,
          outcome: 'perdeu' as const,
          variacao: -10,
          resultadoMsg:
            'O resultado deu zebra e você perdeu R$ 10,00. As estatísticas dos influenciadores são manipuladas com contas demo.',
          conceito: 'Ilusão de Conhecimento',
          explicacao:
            'Grupos VIP vendem a ilusão de que o futebol é previsível. Matematicamente, a margem embutida (vigorish) garante que a banca sempre lucre no agregado.',
        },
        {
          rotulo: 'Não apostar e manter os R$ 100 protegidos',
          valor: 0,
          outcome: 'ganhou' as const,
          variacao: 0,
          resultadoMsg:
            'Você evitou a armadilha do marketing predatório e manteve seus R$ 100 intactos.',
          conceito: 'Pensamento Crítico & Preservação',
          explicacao:
            'A única decisão onde a expectativa matemática não é negativa é não participar de jogos com margem favorável à casa.',
        },
      ],
    },
    {
      rodada: 2,
      titulo: 'Cenário 2: O Caça-Níquel Virtual ("Jogo do Tigrinho / Aviator")',
      descricao:
        'Você vê animações coloridas, sons empolgantes e luzes simulando uma máquina prestes a "soltar a cartinha".',
      opcoes: [
        {
          rotulo: 'Girar 3 vezes no valor de R$ 10 cada (Total R$ 30)',
          valor: 30,
          outcome: 'quase_ganhou' as const,
          variacao: -25, // ganha 5 de volta numa rodada, perde 30 total = -25
          resultadoMsg:
            'Você perdeu duas rodadas inteiras e na terceira vieram dois símbolos iguais! Ganhou R$ 5,00, mas gastou R$ 30,00 (Prejuízo líquido de R$ 25,00).',
          conceito: 'Perdas Disfarçadas de Ganhos (LDWs)',
          explicacao:
            'As máquinas tocam música de festa mesmo quando você gasta R$ 10 e "ganha" R$ 2. O cérebro processa o som festivo como vitória, mascarando o prejuízo financeiro líquido.',
        },
        {
          rotulo: 'Apostar R$ 15 em uma única rodada "alavancada"',
          valor: 15,
          outcome: 'perdeu' as const,
          variacao: -15,
          resultadoMsg:
            'A rodada terminou em 2 segundos e seu saldo foi consumido instantaneamente. Prejuízo de R$ 15,00.',
          conceito: 'Ritmo Rápido de Jogo (Loss Velocity)',
          explicacao:
            'A velocidade acelerada entre uma aposta e outra impede a reflexão racional do córtex pré-frontal, levando a perdas financeiras em série sem percepção de tempo.',
        },
      ],
    },
    {
      rodada: 3,
      titulo: 'Cenário 3: O Impulso de "Recuperar o Prejuízo" (Chasing Losses)',
      descricao:
        'Seu saldo diminuiu em relação aos R$ 100 iniciais. Uma sensação de ansiedade e frustração surge na mente.',
      opcoes: [
        {
          rotulo: 'Apostar o restante em uma Odd alta para tentar voltar aos R$ 100',
          valor: 35,
          outcome: 'perdeu' as const,
          variacao: -35,
          resultadoMsg:
            'A aposta de desespero não se concretizou. Seu capital sofreu uma drenagem severa de R$ 35,00.',
          conceito: 'Efeito Chasing Losses (Perseguição de Perdas)',
          explicacao:
            'Este é o sintoma clínico mais característico da ludopatia: quanto mais dinheiro se perde, maior a tentação de arriscar quantias maiores para tentar zerar a dívida, acelerando a ruína financeira.',
        },
        {
          rotulo: 'Reconhecer que o algoritmo é desfavorável e parar imediatamente',
          valor: 0,
          outcome: 'ganhou' as const,
          variacao: 0,
          resultadoMsg:
            'Parabéns! Você aplicou o freio cognitivo antes de sofrer a perda total.',
          conceito: 'Autocontrole e Cessação',
          explicacao:
            'Saber parar diante do prejuízo é a decisão mais difícil psicologicamente, mas é a única que interrompe o ciclo vicioso de endividamento.',
        },
      ],
    },
  ];

  const handleEscolha = (opcao: (typeof cenarios)[0]['opcoes'][0]) => {
    const novoSaldo = Math.max(0, saldo + opcao.variacao);
    setSaldo(novoSaldo);

    const novaRodada: Rodada = {
      numero: rodadaAtual,
      decisao: opcao.rotulo,
      valorApostado: opcao.valor,
      resultado: opcao.outcome,
      saldoApos: novoSaldo,
      mensagem: opcao.resultadoMsg,
      conceitoExplicado: opcao.explicacao,
      nomeConceito: opcao.conceito,
    };

    setHistorico((prev) => [...prev, novaRodada]);

    if (rodadaAtual < cenarios.length && novoSaldo > 0) {
      setRodadaAtual(rodadaAtual + 1);
    } else {
      setFinalizado(true);
    }
  };

  const reiniciarSimulador = () => {
    setSaldo(100);
    setRodadaAtual(1);
    setFinalizado(false);
    setHistorico([
      {
        numero: 0,
        decisao: 'Início da Simulação',
        valorApostado: 0,
        resultado: 'ganhou',
        saldoApos: 100,
        mensagem: 'Você recebeu R$ 100,00 fictícios para a simulação.',
        conceitoExplicado: 'Saldo inicial neutro para demonstrar o comportamento de risco.',
        nomeConceito: 'Ponto de Partida',
      },
    ]);
  };

  const diferencaSaldo = saldo - 100;
  const cenarioAtual = cenarios[rodadaAtual - 1];

  return (
    <section id="simulador" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#0e1013] text-[#f4f1ea] border-b border-[#23272d]">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Cabeçalho */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-[#d8a13b]/15 text-[#d8a13b] border border-[#d8a13b]/30 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5 text-[#d8a13b]" />
            Experiência Interativa Pedagógica
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight text-[#f4f1ea]">
            Desafio dos R$ 100:{' '}
            <span className="text-[#e4552e]">Você Realmente Controla o Jogo?</span>
          </h2>
          <p className="text-[#a9adb6] text-base sm:text-lg leading-relaxed">
            Você começa com <strong className="text-[#f4f1ea]">R$ 100,00 virtuais</strong>.
            A cada rodada, tomará decisões reais em situações típicas do ecossistema de apostas.
            Descubra na prática os vieses cognitivos e a armadilha matemática desenhada para esgotar seus recursos.
          </p>
          <div className="p-3 bg-[#171b21] rounded-xl border border-[#2d323a] text-xs text-[#d8a13b] flex items-center gap-2">
            <Info className="w-4 h-4 flex-shrink-0" />
            <span>
              <strong>Aviso de Ética:</strong> Esta é uma simulação 100% científica e educativa.
              Não utiliza dinheiro real, não incentiva apostas e não possui links comerciais.
            </span>
          </div>
        </div>

        {/* Painel do Simulador */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Coluna Esquerda: Placar de Saldo & Histórico */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#14171b] border-2 border-[#34373b] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
              <span className="text-xs font-mono font-bold uppercase text-[#8a8f99] tracking-wider block">
                Painel do Apostador
              </span>

              {/* Saldo Dinâmico */}
              <div className="p-5 bg-[#0e1013] rounded-2xl border border-[#23272d] flex items-center justify-between">
                <div>
                  <span className="text-xs text-[#8a8f99] block">Saldo Atual Fictício</span>
                  <span
                    className={`text-3xl sm:text-4xl font-black font-mono ${
                      saldo > 70
                        ? 'text-[#50fa7b]'
                        : saldo > 30
                        ? 'text-[#d8a13b]'
                        : 'text-[#e4552e]'
                    }`}
                  >
                    R$ {saldo.toFixed(2)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-[#8a8f99] block">Resultado</span>
                  <span
                    className={`text-sm font-bold font-mono ${
                      diferencaSaldo >= 0 ? 'text-[#50fa7b]' : 'text-[#e4552e]'
                    }`}
                  >
                    {diferencaSaldo >= 0 ? `+R$ ${diferencaSaldo.toFixed(2)}` : `-R$ ${Math.abs(diferencaSaldo).toFixed(2)}`}
                  </span>
                </div>
              </div>

              {/* Barra Visual de Evolução do Saldo */}
              <div>
                <div className="flex justify-between text-xs text-[#8a8f99] mb-1 font-mono">
                  <span>R$ 0,00</span>
                  <span>R$ 50,00</span>
                  <span>R$ 100,00</span>
                </div>
                <div className="w-full h-3 bg-[#0e1013] rounded-full overflow-hidden border border-[#23272d]">
                  <div
                    className={`h-full transition-all duration-500 rounded-full ${
                      saldo > 60
                        ? 'bg-[#50fa7b]'
                        : saldo > 25
                        ? 'bg-[#d8a13b]'
                        : 'bg-[#e4552e]'
                    }`}
                    style={{ width: `${Math.min(100, Math.max(0, saldo))}%` }}
                  ></div>
                </div>
              </div>

              {/* Histórico das Jogadas */}
              <div className="space-y-3 pt-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#a9adb6] block">
                  Linha do Tempo das Decisões:
                </span>
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {historico.slice(1).map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-[#0e1013] rounded-xl border border-[#23272d] text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between font-mono font-bold">
                        <span className="text-[#d8a13b]">Rodada #{item.numero}</span>
                        <span
                          className={
                            item.resultado === 'ganhou'
                              ? 'text-[#50fa7b]'
                              : 'text-[#e4552e]'
                          }
                        >
                          Saldo: R$ {item.saldoApos.toFixed(2)}
                        </span>
                      </div>
                      <p className="text-[#c5c5c5]">{item.decisao}</p>
                      <div className="pt-1 flex items-center gap-1.5 text-[11px] text-[#ff9f87]">
                        <AlertTriangle className="w-3 h-3 flex-shrink-0 text-[#e4552e]" />
                        <span>{item.nomeConceito}</span>
                      </div>
                    </div>
                  ))}
                  {historico.length <= 1 && (
                    <p className="text-xs text-[#717682] italic">
                      Nenhuma aposta realizada ainda. Faça sua primeira escolha ao lado!
                    </p>
                  )}
                </div>
              </div>

              {/* Botão Reiniciar */}
              <button
                onClick={reiniciarSimulador}
                className="w-full flex items-center justify-center gap-2 bg-[#1f242c] hover:bg-[#282f3a] text-[#f4f1ea] py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider border border-[#34373b] transition cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-[#d8a13b]" />
                Reiniciar Simulação com R$ 100
              </button>
            </div>
          </div>

          {/* Coluna Direita: O Cenário Interativo & Diagnóstico */}
          <div className="lg:col-span-7">
            {!finalizado && cenarioAtual ? (
              <div className="bg-[#14171b] border-2 border-[#e4552e]/50 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-extrabold uppercase bg-[#e4552e]/20 text-[#e4552e] px-3 py-1 rounded-full">
                    Rodada {cenarioAtual.rodada} de {cenarios.length}
                  </span>
                  <span className="text-xs text-[#8a8f99]">Simulador Cognitivo</span>
                </div>

                <div>
                  <h3 className="text-2xl font-black uppercase text-[#f4f1ea]">
                    {cenarioAtual.titulo}
                  </h3>
                  <p className="text-sm text-[#c5c5c5] mt-2 leading-relaxed">
                    {cenarioAtual.descricao}
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#d8a13b] block">
                    Qual é a sua decisão?
                  </span>
                  <div className="space-y-3">
                    {cenarioAtual.opcoes.map((op, i) => (
                      <button
                        key={i}
                        onClick={() => handleEscolha(op)}
                        className="w-full p-4 rounded-2xl bg-[#0e1013] hover:bg-[#1a1e26] border border-[#2d323a] hover:border-[#e4552e] text-left transition-all group cursor-pointer flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-[#f4f1ea] group-hover:text-[#d8a13b] transition-colors">
                            {op.rotulo}
                          </p>
                          <span className="text-xs text-[#8a8f99]">
                            {op.valor > 0
                              ? `Risco de perda: R$ ${op.valor.toFixed(2)}`
                              : 'Sem exposição financeira'}
                          </span>
                        </div>
                        <ChevronRight className="w-5 h-5 text-[#8a8f99] group-hover:text-[#e4552e] group-hover:translate-x-1 transition-all flex-shrink-0" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Último feedback pedagógico */}
                {historico.length > 1 && (
                  <div className="p-4 bg-[#1b1e24] border border-[#2d323a] rounded-2xl space-y-2 animate-fadeIn">
                    <span className="text-xs font-extrabold uppercase text-[#d8a13b] flex items-center gap-1.5">
                      <Brain className="w-4 h-4" />
                      Conceito revelado na rodada anterior:
                    </span>
                    <p className="text-xs text-[#c5c5c5] leading-relaxed">
                      {historico[historico.length - 1].conceitoExplicado}
                    </p>
                  </div>
                )}
              </div>
            ) : (
              /* TELA FINAL DE DIAGNÓSTICO EDUCATIVO */
              <div className="bg-[#14171b] border-2 border-[#50fa7b]/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl animate-fadeIn">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-xl bg-[#50fa7b]/20 flex items-center justify-center text-[#50fa7b]">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black uppercase text-[#f4f1ea]">
                      Diagnóstico Final da Simulação
                    </h3>
                    <span className="text-xs text-[#a9adb6]">
                      Análise comportamental elaborada pelo projeto CEEP
                    </span>
                  </div>
                </div>

                <div className="p-5 bg-[#0e1013] rounded-2xl border border-[#23272d] space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[#8a8f99] uppercase font-bold">
                      Saldo Final:
                    </span>
                    <span
                      className={`text-2xl font-black font-mono ${
                        saldo >= 100
                          ? 'text-[#50fa7b]'
                          : saldo >= 50
                          ? 'text-[#d8a13b]'
                          : 'text-[#e4552e]'
                      }`}
                    >
                      R$ {saldo.toFixed(2)}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-[#c5c5c5] leading-relaxed">
                    {saldo < 100
                      ? `Você começou com R$ 100,00 e terminou com R$ ${saldo.toFixed(
                          2
                        )}. Essa perda não foi um "azar": na matemática dos jogos, cada clique tem um valor esperado negativo (House Edge). No longo prazo, a probabilidade de ruína é de quase 100%.`
                      : 'Você conseguiu preservar seu saldo tomando decisões conservadoras. No entanto, em plataformas comerciais reais, os algoritmos são programados para testar sua resistência com bônus e notificações até que você volte a apostar.'}
                  </p>
                </div>

                {/* 3 Lições Científicas Principais */}
                <div className="space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#d8a13b] block">
                    Os 3 Truques Psicológicos Identificados:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 bg-[#0e1013] rounded-xl border border-[#23272d] text-xs space-y-1">
                      <span className="font-bold text-[#e4552e] block">
                        1. Quase Vitória
                      </span>
                      <p className="text-[#8a8f99]">
                        "Bater na trave" estimula a dopamina e engana o cérebro dizendo que você está melhorando.
                      </p>
                    </div>

                    <div className="p-3 bg-[#0e1013] rounded-xl border border-[#23272d] text-xs space-y-1">
                      <span className="font-bold text-[#d8a13b] block">
                        2. Ilusão de Controle
                      </span>
                      <p className="text-[#8a8f99]">
                        Achar que método, grupo de sinais ou planilha anula a margem da casa de aposta.
                      </p>
                    </div>

                    <div className="p-3 bg-[#0e1013] rounded-xl border border-[#23272d] text-xs space-y-1">
                      <span className="font-bold text-[#ffb4a2] block">
                        3. Chasing Losses
                      </span>
                      <p className="text-[#8a8f99]">
                        Tentar recuperar a perda apostando mais alto é a porta de entrada para dívidas impagáveis.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap gap-3">
                  <button
                    onClick={reiniciarSimulador}
                    className="inline-flex items-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] text-white px-6 py-3 rounded-full font-bold text-xs uppercase tracking-wider transition cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Experimentar Outras Escolhas
                  </button>
                  <a
                    href="#quiz"
                    className="inline-flex items-center gap-2 bg-[#1a1e24] hover:bg-[#252b33] text-[#d8a13b] border border-[#3b3f46] px-6 py-3 rounded-full font-bold text-xs uppercase tracking-wider transition"
                  >
                    Fazer o Quiz Científico
                    <ChevronRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
