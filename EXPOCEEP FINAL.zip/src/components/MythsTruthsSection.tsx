import React, { useState } from 'react';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  Sparkles,
  BookOpen,
  Filter,
} from 'lucide-react';

interface MitoVerdade {
  id: number;
  categoria: 'algoritmos' | 'esportes' | 'psicologia' | 'legislacao';
  mito: string;
  verdade: string;
  detalheCientifico: string;
}

export const MythsTruthsSection: React.FC = () => {
  const [filtro, setFiltro] = useState<string>('todos');
  const [cardAberto, setCardAberto] = useState<number | null>(null);

  const dados: MitoVerdade[] = [
    {
      id: 1,
      categoria: 'algoritmos',
      mito: 'Existe "horário pagante" ou método com robô para ganhar no Tigrinho / Aviator.',
      verdade:
        'Todo jogo eletrônico utiliza RNG (Gerador de Números Pseudoaleatórios) matemático independente. Não existem horários com maior probabilidade de ganho.',
      detalheCientifico:
        'Os algoritmos são calibrados com margem da casa (House Edge) embutida em cada instrução de código. Vendedores de "robôs" lucram com links de afiliação sobre o dinheiro que você perde.',
    },
    {
      id: 2,
      categoria: 'esportes',
      mito: 'Entender muito de futebol transforma aposta esportiva em investimento seguro.',
      verdade:
        'Apostas esportivas não são investimento financeiro. As cotações (odds) contêm taxas embutidas (vigorish) que matematicamente garantem o lucro da banca.',
      detalheCientifico:
        'Em ativos financeiros reais, há criação de valor econômico ou juros. Em apostas, trata-se de um jogo de soma negativa, onde a esmagadora maioria perde capital com o passar dos meses.',
    },
    {
      id: 3,
      categoria: 'legislacao',
      mito: 'A proibição recente das apostas de quota fixa eliminou 100% dos riscos no país.',
      verdade:
        'A proibição é um marco regulatório necessário, mas o mercado paralelo e sites clandestinos hospedados no exterior continuam tentando capturar vulneráveis.',
      detalheCientifico:
        'Sem políticas de acolhimento nos CAPS/SUS e sem educação financeira nas escolas, a demanda psicológica permanece ativa no submundo da internet.',
    },
    {
      id: 4,
      categoria: 'psicologia',
      mito: 'Vício em jogo é apenas falta de caráter ou de força de vontade da pessoa.',
      verdade:
        'O transtorno do jogo compulsivo (ludopatia) é uma patologia neuropsiquiátrica reconhecida pela OMS no CID-11 (código 6C50).',
      detalheCientifico:
        'Exames de neuroimagem funcional mostram que as descargas de dopamina causadas pelo jogo ativam os mesmos receptores cerebrais que substâncias psicoativas pesadas.',
    },
    {
      id: 5,
      categoria: 'psicologia',
      mito: 'Se perdi R$ 500, a melhor saída é apostar mais R$ 500 para tentar recuperar e zerar a conta.',
      verdade:
        'Esse é o mecanismo destrutivo conhecido como "Chasing Losses". Apostar para recuperar é a causa primária da ruína financeira.',
      detalheCientifico:
        'Como a expectativa matemática de cada aposta individual é negativa, aumentar o volume financeiro apostado apenas acelera estatisticamente a probabilidade de falência do jogador.',
    },
    {
      id: 6,
      categoria: 'algoritmos',
      mito: 'Apostar apenas valores pequenos (R$ 2 ou R$ 5) não oferece perigo à saúde.',
      verdade:
        'A tolerância neurobiológica faz com que o cérebro se acostume rapidamente aos estímulos, exigindo valores maiores e maior frequência para sentir o mesmo prazer.',
      detalheCientifico:
        'Muitas famílias entram em dívidas não por uma aposta única milionária, mas por dezenas de transações diárias de pequenos valores que somam valores superiores à renda mensal.',
    },
  ];

  const itensFiltrados =
    filtro === 'todos'
      ? dados
      : dados.filter((item) => item.categoria === filtro);

  return (
    <section id="mitos" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#0e1013] text-[#f4f1ea] border-b border-[#23272d]">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Cabeçalho */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-[#d8a13b]/15 text-[#d8a13b] border border-[#d8a13b]/30 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
            <BookOpen className="w-3.5 h-3.5 text-[#d8a13b]" />
            Combate à Desinformação
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight text-[#f4f1ea]">
            Mitos e Verdades:{' '}
            <span className="text-[#e4552e]">A Ciência Contra o Marketing</span>
          </h2>
          <p className="text-[#a9adb6] text-base sm:text-lg leading-relaxed">
            As narrativas criadas para atrair novos apostadores misturam meias-verdades e promessas sedutoras.
            Analise cada alegação confrontada com dados científicos e estatísticos reais.
          </p>
        </div>

        {/* Filtros por Categoria */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
          <span className="text-[#8a8f99] flex items-center gap-1 mr-2">
            <Filter className="w-3.5 h-3.5" /> Filtrar por:
          </span>
          {[
            { id: 'todos', label: 'Todos os Fatos' },
            { id: 'algoritmos', label: 'Algoritmos & Jogos' },
            { id: 'esportes', label: 'Apostas Esportivas' },
            { id: 'psicologia', label: 'Neurociência & Saúde' },
            { id: 'legislacao', label: 'Legislação & Proibição' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFiltro(cat.id)}
              className={`px-3.5 py-1.5 rounded-full transition-all cursor-pointer ${
                filtro === cat.id
                  ? 'bg-[#e4552e] text-white font-bold'
                  : 'bg-[#1a1e24] text-[#a9adb6] hover:text-[#f4f1ea] border border-[#2d323a]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Grade de Cards Mitos vs Verdades */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {itensFiltrados.map((item) => {
            const estaAberto = cardAberto === item.id;
            return (
              <div
                key={item.id}
                className="bg-[#14171b] border border-[#262b34] rounded-3xl p-6 sm:p-7 flex flex-col justify-between space-y-6 hover:border-[#3e4554] transition-all shadow-lg"
              >
                <div className="space-y-4">
                  {/* Bloco do Mito */}
                  <div className="p-4 bg-[#231515] border border-[#e4552e]/30 rounded-2xl space-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-[#e4552e]">
                      <XCircle className="w-4 h-4 text-[#e4552e]" />
                      Mito Popular
                    </div>
                    <p className="text-sm font-bold text-[#f4f1ea] leading-snug">
                      "{item.mito}"
                    </p>
                  </div>

                  {/* Bloco da Verdade */}
                  <div className="p-4 bg-[#122218] border border-[#2e7d5b]/30 rounded-2xl space-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-[#50fa7b]">
                      <CheckCircle2 className="w-4 h-4 text-[#50fa7b]" />
                      Fato Científico
                    </div>
                    <p className="text-xs sm:text-sm text-[#d4f8de] leading-relaxed">
                      {item.verdade}
                    </p>
                  </div>

                  {/* Detalhe Científico Aprofundado */}
                  {estaAberto && (
                    <div className="p-3.5 bg-[#0e1013] rounded-xl border border-[#23272d] text-xs text-[#a9adb6] leading-relaxed space-y-1 animate-fadeIn">
                      <span className="font-mono text-[#d8a13b] font-bold block text-[10px] uppercase">
                        Fundamentação Técnica:
                      </span>
                      <p>{item.detalheCientifico}</p>
                    </div>
                  )}
                </div>

                {/* Botão Ver Explicação Técnica */}
                <button
                  onClick={() => setCardAberto(estaAberto ? null : item.id)}
                  className="w-full text-center text-xs font-bold uppercase tracking-wider py-2 rounded-xl text-[#d8a13b] hover:text-white bg-[#1a1e24] hover:bg-[#252b33] border border-[#34373b] transition cursor-pointer"
                >
                  {estaAberto ? 'Ocultar Detalhe' : 'Ver Embasa­mento Técnico'}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
