import React, { useState, useEffect } from 'react';
import {
  Database,
  X,
  Table,
  Layers,
  Code,
  CheckCircle,
  Copy,
  Download,
  Terminal,
  RefreshCw,
  ExternalLink,
  ShieldAlert,
} from 'lucide-react';
import { DbInspectionData } from '../types.ts';

interface DatabaseInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRefresh: () => void;
}

export const DatabaseInspectorModal: React.FC<DatabaseInspectorModalProps> = ({
  isOpen,
  onClose,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<'der' | 'categorias' | 'assinaturas' | 'pesquisa' | 'api' | 'sql'>('der');
  const [dbData, setDbData] = useState<DbInspectionData | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Estado para o teste da Rota Principal (Comprovação JSON Etapa 1)
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [apiLoading, setApiLoading] = useState(false);

  const carregarDados = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/db/inspector');
      if (res.ok) {
        const data = await res.json();
        setDbData(data);
      }
    } catch (err) {
      console.error('Erro ao carregar dados do banco:', err);
    } finally {
      setLoading(false);
    }
  };

  const testarRotaPrincipal = async () => {
    setApiLoading(true);
    try {
      const res = await fetch('/api/status');
      const json = await res.json();
      setApiResponse(json);
    } catch (err: any) {
      setApiResponse({ erro: 'Falha ao conectar com o endpoint', detalhe: err.message });
    } finally {
      setApiLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      carregarDados();
      testarRotaPrincipal();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const copiarSql = () => {
    if (dbData?.scriptSql) {
      navigator.clipboard.writeText(dbData.scriptSql);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const baixarSql = () => {
    if (dbData?.scriptSql) {
      const blob = new Blob([dbData.scriptSql], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'script.sql';
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-xs animate-fadeIn">
      <div className="bg-[#0e1013] border border-[#34373b] w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Cabeçalho do Modal */}
        <div className="p-4 sm:p-5 border-b border-[#23272d] flex items-center justify-between bg-[#14171b]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#d8a13b]/20 flex items-center justify-center text-[#d8a13b]">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-[#f4f1ea] uppercase">
                  Estrutura do Banco de Dados SQLite & DER
                </h3>
                <span className="bg-[#2e7d5b] text-white text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                  Etapa 1 OK
                </span>
              </div>
              <p className="text-xs text-[#a9adb6]">
                Projeto CEEP Contra as BETS • bd/script.sql • SQLite 3 Relacional (1:N)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                carregarDados();
                testarRotaPrincipal();
                onRefresh();
              }}
              className="p-2 text-[#a9adb6] hover:text-[#d8a13b] hover:bg-[#1f242c] rounded-lg transition"
              title="Recarregar dados do banco"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-[#a9adb6] hover:text-white hover:bg-[#1f242c] rounded-lg transition"
              title="Fechar painel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Abas de Navegação */}
        <div className="flex items-center gap-2 px-4 pt-3 border-b border-[#23272d] bg-[#111317] overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('der')}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-t-lg transition-colors whitespace-nowrap ${
              activeTab === 'der'
                ? 'bg-[#1a1e24] text-[#d8a13b] border-t-2 border-[#d8a13b]'
                : 'text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Layers className="w-4 h-4" />
            Diagrama DER (1:N)
          </button>

          <button
            onClick={() => setActiveTab('categorias')}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-t-lg transition-colors whitespace-nowrap ${
              activeTab === 'categorias'
                ? 'bg-[#1a1e24] text-[#d8a13b] border-t-2 border-[#d8a13b]'
                : 'text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Table className="w-4 h-4" />
            Tabela categorias (1)
            {dbData?.tables?.categorias && (
              <span className="text-[10px] bg-[#23272d] px-1.5 py-0.2 rounded text-[#d8a13b]">
                {dbData.tables.categorias.rows.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('assinaturas')}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-t-lg transition-colors whitespace-nowrap ${
              activeTab === 'assinaturas'
                ? 'bg-[#1a1e24] text-[#d8a13b] border-t-2 border-[#d8a13b]'
                : 'text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Table className="w-4 h-4" />
            Tabela assinaturas (N)
            {dbData?.tables?.assinaturas && (
              <span className="text-[10px] bg-[#23272d] px-1.5 py-0.2 rounded text-[#e4552e]">
                {dbData.tables.assinaturas.rows.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('pesquisa')}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-t-lg transition-colors whitespace-nowrap ${
              activeTab === 'pesquisa'
                ? 'bg-[#1a1e24] text-[#d8a13b] border-t-2 border-[#d8a13b]'
                : 'text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Table className="w-4 h-4" />
            Tabela pesquisa_respostas
            {dbData?.tables?.pesquisa_respostas && (
              <span className="text-[10px] bg-[#23272d] px-1.5 py-0.2 rounded text-[#50fa7b]">
                {dbData.tables.pesquisa_respostas.rows.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('api')}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-t-lg transition-colors whitespace-nowrap ${
              activeTab === 'api'
                ? 'bg-[#1a1e24] text-[#d8a13b] border-t-2 border-[#d8a13b]'
                : 'text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Terminal className="w-4 h-4" />
            Comprovação JSON (API)
          </button>

          <button
            onClick={() => setActiveTab('sql')}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-t-lg transition-colors whitespace-nowrap ${
              activeTab === 'sql'
                ? 'bg-[#1a1e24] text-[#d8a13b] border-t-2 border-[#d8a13b]'
                : 'text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Code className="w-4 h-4" />
            Script SQL (DDL)
          </button>
        </div>

        {/* Conteúdo das Abas */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-[#14171b] text-sm text-[#c5c5c5]">
          {/* ABA 1: DIAGRAMA DER */}
          {activeTab === 'der' && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-[#0e1013] border border-[#2d323a] rounded-xl p-5">
                <h4 className="text-xs uppercase font-extrabold tracking-wider text-[#d8a13b] mb-4 flex items-center gap-2">
                  <Layers className="w-4 h-4" />
                  Diagrama Entidade-Relacionamento (DER) Conforme Guia de Execução
                </h4>

                {/* Representação Gráfica do DER do PDF */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                  {/* Entidade CATEGORIAS (Lado 1) */}
                  <div className="md:col-span-4 bg-[#171b21] border-2 border-[#d8a13b] rounded-xl overflow-hidden shadow-lg">
                    <div className="bg-[#d8a13b] text-[#0e1013] px-3 py-2 font-black text-center text-xs tracking-wider uppercase flex items-center justify-between">
                      <span>CATEGORIAS</span>
                      <span className="text-[10px] bg-black/20 px-1.5 rounded font-mono">Lado (1)</span>
                    </div>
                    <div className="p-3 text-xs font-mono space-y-1.5 bg-[#12151a]">
                      <div className="flex items-center justify-between border-b border-[#2d323a] pb-1 text-[#f4f1ea]">
                        <span className="font-bold text-[#d8a13b]">🔑 PK id</span>
                        <span className="text-[10px] text-[#8a8f99]">INTEGER</span>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span>nome_alerta</span>
                        <span className="text-[10px] text-[#8a8f99]">TEXT NOT NULL</span>
                      </div>
                    </div>
                  </div>

                  {/* Conector Relacional 1:N */}
                  <div className="md:col-span-3 text-center py-2 md:py-0 flex flex-col items-center justify-center">
                    <span className="text-xs font-mono text-[#d8a13b] font-bold bg-[#1d2129] px-3 py-1 rounded-full border border-[#34373b]">
                      (1:N) UM PARA MUITOS
                    </span>
                    <div className="hidden md:flex items-center w-full justify-center text-[#e4552e] my-1 text-lg font-bold">
                      ───◄ 
                    </div>
                    <span className="text-[11px] text-[#8a8f99] max-w-[180px] mt-1">
                      1 Categoria possui N Assinaturas
                    </span>
                  </div>

                  {/* Entidade ASSINATURAS (Lado N) */}
                  <div className="md:col-span-5 bg-[#171b21] border-2 border-[#e4552e] rounded-xl overflow-hidden shadow-lg">
                    <div className="bg-[#e4552e] text-white px-3 py-2 font-black text-center text-xs tracking-wider uppercase flex items-center justify-between">
                      <span>ASSINATURAS</span>
                      <span className="text-[10px] bg-black/20 px-1.5 rounded font-mono">Lado (N)</span>
                    </div>
                    <div className="p-3 text-xs font-mono space-y-1.5 bg-[#12151a]">
                      <div className="flex items-center justify-between border-b border-[#2d323a] pb-1 text-[#f4f1ea]">
                        <span className="font-bold text-[#e4552e]">🔑 PK id</span>
                        <span className="text-[10px] text-[#8a8f99]">INTEGER</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>nome_completo</span>
                        <span className="text-[10px] text-[#8a8f99]">TEXT NOT NULL</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>email</span>
                        <span className="text-[10px] text-[#8a8f99]">TEXT UNIQUE</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>cpf</span>
                        <span className="text-[10px] text-[#8a8f99]">TEXT UNIQUE</span>
                      </div>
                      <div className="flex items-center justify-between border-t border-[#2d323a] pt-1 text-[#d8a13b]">
                        <span className="font-bold">🔗 FK categoria_id</span>
                        <span className="text-[10px] text-[#d8a13b]">INTEGER NOT NULL</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>comentario</span>
                        <span className="text-[10px] text-[#8a8f99]">TEXT (opcional)</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>data_registro</span>
                        <span className="text-[10px] text-[#8a8f99]">DATETIME</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Explicação da Regra de Negócio (Didática do PDF) */}
              <div className="bg-[#171b21] border border-[#2d323a] rounded-xl p-5 space-y-3">
                <h5 className="text-xs uppercase font-extrabold text-[#f4f1ea] tracking-wider">
                  Analogia Pedagógica (Prateleira de Mercado - Página 5 do Guia):
                </h5>
                <p className="text-xs text-[#a9adb6] leading-relaxed italic border-l-2 border-[#d8a13b] pl-3 py-1">
                  "Pensem em uma prateleira chamada 'Saúde Mental'. Nessa prateleira, nós podemos colocar centenas de folhas de assinaturas de pessoas diferentes (Muitos / N). Porém, se pegarmos uma folha específica (Uma Assinatura), ela só pode estar guardada em uma única prateleira por vez (Um / 1)."
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                  <div className="p-3 bg-[#0e1013] rounded-lg border border-[#23272d]">
                    <span className="text-[#2e7d5b] font-bold">✓ Por que usar a FK categoria_id?</span>
                    <p className="text-[#8a8f99] mt-1">
                      Evita inconsistências de digitação e viabiliza filtros e métricas estatísticas instantâneas.
                    </p>
                  </div>
                  <div className="p-3 bg-[#0e1013] rounded-lg border border-[#23272d]">
                    <span className="text-[#e4552e] font-bold">⚠ Chave Estrangeira Sempre no Lado N:</span>
                    <p className="text-[#8a8f99] mt-1">
                      A chave estrangeira reside em <code className="text-[#d8a13b]">assinaturas</code>, permitindo ilimitados apoiadores por categoria.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ABA 2: TABELA CATEGORIAS */}
          {activeTab === 'categorias' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-base font-bold text-[#f4f1ea] uppercase">
                    Tabela: <span className="text-[#d8a13b] font-mono">categorias</span> (Lado 1)
                  </h4>
                  <p className="text-xs text-[#8a8f99]">Tabela pai contendo as opções padronizadas de alerta.</p>
                </div>
                <span className="text-xs font-mono bg-[#1a1e24] px-2.5 py-1 rounded text-[#d8a13b] border border-[#34373b]">
                  {dbData?.tables?.categorias?.rows?.length || 0} registros
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-[#2d323a] bg-[#0e1013]">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#1a1e24] text-[#d8a13b] uppercase tracking-wider border-b border-[#2d323a]">
                    <tr>
                      <th className="p-3">id (PK)</th>
                      <th className="p-3">nome_alerta (UNIQUE)</th>
                      <th className="p-3 text-right">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#23272d]">
                    {dbData?.tables?.categorias?.rows?.map((row, i) => (
                      <tr key={i} className="hover:bg-[#15181e] transition-colors">
                        <td className="p-3 font-bold text-[#e4552e]">#{row[0]}</td>
                        <td className="p-3 text-[#f4f1ea] font-sans font-semibold">{row[1]}</td>
                        <td className="p-3 text-right">
                          <span className="bg-[#23272d] text-[#a9adb6] text-[10px] px-2 py-0.5 rounded">
                            Ativo
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ABA 3: TABELA ASSINATURAS */}
          {activeTab === 'assinaturas' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-base font-bold text-[#f4f1ea] uppercase">
                    Tabela: <span className="text-[#e4552e] font-mono">assinaturas</span> (Lado N)
                  </h4>
                  <p className="text-xs text-[#8a8f99]">
                    Registros da petição pública vinculados via <code className="text-[#d8a13b]">categoria_id</code>.
                  </p>
                </div>
                <span className="text-xs font-mono bg-[#1a1e24] px-2.5 py-1 rounded text-[#e4552e] border border-[#34373b]">
                  {dbData?.tables?.assinaturas?.rows?.length || 0} assinaturas
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-[#2d323a] bg-[#0e1013]">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#1a1e24] text-[#a9adb6] uppercase tracking-wider border-b border-[#2d323a]">
                    <tr>
                      <th className="p-3 text-[#e4552e]">id</th>
                      <th className="p-3 text-white">nome_completo</th>
                      <th className="p-3 text-[#a9adb6]">email</th>
                      <th className="p-3 text-[#a9adb6]">cpf</th>
                      <th className="p-3 text-[#d8a13b]">categoria_id (FK)</th>
                      <th className="p-3">comentario</th>
                      <th className="p-3">data_registro</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#23272d]">
                    {dbData?.tables?.assinaturas?.rows?.map((row, i) => (
                      <tr key={i} className="hover:bg-[#15181e] transition-colors">
                        <td className="p-3 font-bold text-[#e4552e]">#{row[0]}</td>
                        <td className="p-3 text-[#f4f1ea] font-sans font-medium whitespace-nowrap">{row[1]}</td>
                        <td className="p-3 text-[#8a8f99] whitespace-nowrap">{row[2]}</td>
                        <td className="p-3 text-[#8a8f99] whitespace-nowrap">{row[3]}</td>
                        <td className="p-3 text-[#d8a13b] font-bold">FK: {row[6]}</td>
                        <td className="p-3 text-[#c5c5c5] max-w-xs truncate" title={row[4] || ''}>
                          {row[4] || <span className="text-[#555] italic">Nenhum</span>}
                        </td>
                        <td className="p-3 text-[#8a8f99] whitespace-nowrap">{String(row[5] || '').split(' ')[0]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ABA: TABELA PESQUISA_RESPOSTAS */}
          {activeTab === 'pesquisa' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-base font-bold text-[#f4f1ea] uppercase">
                    Tabela: <span className="text-[#50fa7b] font-mono">pesquisa_respostas</span>
                  </h4>
                  <p className="text-xs text-[#8a8f99]">
                    Respostas dos visitantes da feira de ciências ExpoCEEP sobre percepção e prevenção.
                  </p>
                </div>
                <span className="text-xs font-mono bg-[#1a1e24] px-2.5 py-1 rounded text-[#50fa7b] border border-[#34373b]">
                  {dbData?.tables?.pesquisa_respostas?.rows?.length || 0} respostas
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-[#2d323a] bg-[#0e1013]">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#1a1e24] text-[#a9adb6] uppercase tracking-wider border-b border-[#2d323a]">
                    <tr>
                      <th className="p-3 text-[#50fa7b]">id</th>
                      <th className="p-3 text-white">faixa_etaria</th>
                      <th className="p-3 text-[#d8a13b]">contato_apostas</th>
                      <th className="p-3 text-[#ff8e7b]">proibicao_suficiente</th>
                      <th className="p-3 text-[#50fa7b]">area_prioritaria</th>
                      <th className="p-3 text-[#8a8f99]">criado_em</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#23272d]">
                    {dbData?.tables?.pesquisa_respostas?.rows?.map((row, i) => (
                      <tr key={i} className="hover:bg-[#15181e] transition-colors">
                        <td className="p-3 font-bold text-[#50fa7b]">#{row[0]}</td>
                        <td className="p-3 text-[#f4f1ea] font-sans whitespace-nowrap">{row[1]}</td>
                        <td className="p-3 text-[#d8a13b] font-sans">{row[2]}</td>
                        <td className="p-3 text-[#ff8e7b] font-sans">{row[3]}</td>
                        <td className="p-3 text-[#50fa7b] font-sans">{row[4]}</td>
                        <td className="p-3 text-[#8a8f99] whitespace-nowrap">{String(row[5] || '').split(' ')[0]}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ABA 4: COMPROVAÇÃO JSON (API FLASK / EXPRESS) */}
          {activeTab === 'api' && (
            <div className="space-y-5 animate-fadeIn">
              <div className="bg-[#0e1013] border border-[#2d323a] rounded-xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-sm uppercase font-extrabold text-[#d8a13b] tracking-wider flex items-center gap-2">
                      <Terminal className="w-4 h-4" />
                      Comprovação da Rota Principal (Etapa 1 do Guia)
                    </h4>
                    <p className="text-xs text-[#8a8f99] mt-0.5">
                      Resposta da rota de verificação exigida para o relatório técnico (Página 3 do PDF).
                    </p>
                  </div>
                  <button
                    onClick={testarRotaPrincipal}
                    disabled={apiLoading}
                    className="inline-flex items-center gap-1.5 bg-[#1d2129] hover:bg-[#252a33] text-[#d8a13b] border border-[#3b3f46] px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${apiLoading ? 'animate-spin' : ''}`} />
                    Testar Rota Agora
                  </button>
                </div>

                <div className="p-3 bg-[#171b21] rounded-lg border border-[#2d323a] mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-2 font-mono text-xs">
                    <span className="bg-[#2e7d5b] text-white px-2 py-0.5 rounded font-bold">GET</span>
                    <span className="text-[#f4f1ea]">/api/status</span>
                  </div>
                  <span className="text-[11px] text-[#2e7d5b] font-bold flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" /> 200 OK
                  </span>
                </div>

                {/* Exibição formatada do JSON */}
                <pre className="bg-[#08090b] text-[#50fa7b] p-4 rounded-xl border border-[#23272d] text-xs font-mono overflow-x-auto">
                  {apiResponse ? JSON.stringify(apiResponse, null, 2) : 'Carregando resposta da API...'}
                </pre>
              </div>

              <div className="p-4 bg-[#171b21] rounded-xl border border-[#2d323a] text-xs space-y-2">
                <span className="font-bold text-[#f4f1ea] uppercase">Nota para o Relatório Técnico:</span>
                <p className="text-[#a9adb6]">
                  A rota responde exatamente com a estrutura padronizada solicitada pelo professor no item 6 do Guia de Execução, validando a inicialização do back-end e a conectividade com o banco SQLite.
                </p>
              </div>
            </div>
          )}

          {/* ABA 5: SCRIPT SQL DDL */}
          {activeTab === 'sql' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-[#f4f1ea] uppercase">
                    Arquivo: <code className="text-[#d8a13b] font-mono">bd/script.sql</code>
                  </h4>
                  <p className="text-xs text-[#8a8f99]">Comandos DDL e seeds para criação do banco SQLite.</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={copiarSql}
                    className="inline-flex items-center gap-1.5 bg-[#1a1e24] hover:bg-[#252b33] text-[#f4f1ea] border border-[#3b3f46] px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5 text-[#2e7d5b]" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copiar SQL
                      </>
                    )}
                  </button>

                  <button
                    onClick={baixarSql}
                    className="inline-flex items-center gap-1.5 bg-[#e4552e] hover:bg-[#b8431f] text-white px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Baixar script.sql
                  </button>
                </div>
              </div>

              <pre className="bg-[#08090b] text-[#f8f8f2] p-4 rounded-xl border border-[#23272d] text-xs font-mono overflow-x-auto max-h-[380px] leading-relaxed">
                {dbData?.scriptSql || '-- Carregando script.sql...'}
              </pre>
            </div>
          )}
        </div>

        {/* Rodapé do Modal */}
        <div className="p-4 border-t border-[#23272d] bg-[#0e1013] flex flex-wrap items-center justify-between gap-3 text-xs text-[#8a8f99]">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#2e7d5b]"></span>
              SQLite Online: <code className="text-[#d8a13b] ml-1">bd/peticao.db</code>
            </span>
          </div>

          <button
            onClick={onClose}
            className="bg-[#23272d] hover:bg-[#2e343e] text-[#f4f1ea] px-4 py-1.5 rounded-lg font-bold text-xs transition"
          >
            Fechar Inspetor
          </button>
        </div>
      </div>
    </div>
  );
};
