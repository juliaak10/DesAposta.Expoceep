import React from 'react';
import { BarChart3, Database, PieChart, Layers, ArrowUpRight } from 'lucide-react';
import { EstatisticaCategoria } from '../types.ts';

interface DatabaseStatsProps {
  estatisticas: EstatisticaCategoria[];
  totalAssinaturas: number;
  onOpenDatabase: () => void;
}

export const DatabaseStats: React.FC<DatabaseStatsProps> = ({
  estatisticas,
  totalAssinaturas,
  onOpenDatabase,
}) => {
  const getCorCategoria = (id: number) => {
    switch (id) {
      case 1:
        return { bg: 'bg-[#e4552e]', text: 'text-[#e4552e]', bar: 'bg-[#e4552e]' };
      case 2:
        return { bg: 'bg-[#d8a13b]', text: 'text-[#d8a13b]', bar: 'bg-[#d8a13b]' };
      case 3:
        return { bg: 'bg-[#2e7d5b]', text: 'text-[#2e7d5b]', bar: 'bg-[#2e7d5b]' };
      default:
        return { bg: 'bg-[#3b82f6]', text: 'text-[#3b82f6]', bar: 'bg-[#3b82f6]' };
    }
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#0e1013] text-[#f4f1ea] border-b border-[#23272d]" id="estatisticas">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-[#d8a13b] text-xs font-extrabold uppercase tracking-widest mb-2">
              <BarChart3 className="w-4 h-4" />
              Estatísticas Relacionais (1:N)
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold uppercase tracking-tight text-[#f4f1ea]">
              Motivações Registradas na Petição
            </h2>
            <p className="text-[#a9adb6] text-base mt-2">
              Dados agregados via consulta SQL direta com chave estrangeira (<code className="text-xs bg-[#1d2129] text-[#d8a13b] px-1.5 py-0.5 rounded font-mono">categoria_id</code>) agrupada pela tabela <code className="text-xs bg-[#1d2129] text-[#d8a13b] px-1.5 py-0.5 rounded font-mono">categorias</code>.
            </p>
          </div>

          <button
            onClick={onOpenDatabase}
            className="inline-flex items-center gap-2 bg-[#1c2027] hover:bg-[#252b34] text-[#d8a13b] border border-[#34373b] px-4 py-2 rounded-xl text-xs font-bold transition-all self-start md:self-auto"
          >
            <Database className="w-4 h-4 text-[#d8a13b]" />
            Ver Consulta SQL e Dados Brutos
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {estatisticas.map((stat) => {
            const cores = getCorCategoria(stat.categoria_id);
            return (
              <div
                key={stat.categoria_id}
                className="bg-[#14171b] border border-[#2d323a] hover:border-[#3d444f] rounded-2xl p-6 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[11px] font-mono text-[#8a8f99] bg-[#1d2129] px-2 py-0.5 rounded">
                      FK ID: #{stat.categoria_id}
                    </span>
                    <span className="text-xs font-bold text-[#d8a13b]">{stat.porcentagem}% dos apoios</span>
                  </div>

                  <h3 className="text-xl font-black text-[#f4f1ea] uppercase tracking-wide mb-1">
                    {stat.nome_alerta}
                  </h3>

                  <div className="flex items-baseline gap-2 mt-4">
                    <span className="text-4xl font-extrabold text-[#f4f1ea]">{stat.total}</span>
                    <span className="text-xs text-[#8a8f99] uppercase font-semibold">assinaturas</span>
                  </div>
                </div>

                <div className="mt-6">
                  <div className="w-full h-2.5 bg-[#23272d] rounded-full overflow-hidden">
                    <div
                      className={`h-full ${cores.bar} rounded-full transition-all duration-500`}
                      style={{ width: `${Math.max(stat.porcentagem, 4)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Nota Pedagógica do Guia CEEP */}
        <div className="mt-8 p-5 bg-[#171b21] border border-[#2d323a] rounded-xl flex items-start gap-3.5 text-xs text-[#a9adb6]">
          <Layers className="w-5 h-5 text-[#d8a13b] flex-shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-[#f4f1ea] uppercase mr-1">Regra de Negócio Implementada:</span>
            A relação 1:N (Um para Muitos) garante que cada assinatura registrada na tabela <span className="font-mono text-[#d8a13b]">assinaturas</span> referencia uma categoria padronizada na tabela <span className="font-mono text-[#d8a13b]">categorias</span>. Isso elimina redundâncias, impede variações de digitação e viabiliza a geração instantânea destes percentuais.
          </div>
        </div>
      </div>
    </section>
  );
};
