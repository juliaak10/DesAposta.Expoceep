import React from 'react';
import { TrendingDown, Brain, Users, Clock, AlertOctagon, Scale } from 'lucide-react';

export const ProblemCards: React.FC = () => {
  const cartoes = [
    {
      titulo: 'Endividamento',
      descricao: 'Tentar recuperar dinheiro perdido pode multiplicar dívidas bancárias, empréstimos e cartões.',
      icone: TrendingDown,
      destaque: 'Impacto Financeiro',
    },
    {
      titulo: 'Saúde mental',
      descricao: 'A perda de controle está diretamente ligada a quadros graves de ansiedade, insônia, depressão e estresse agudo.',
      icone: Brain,
      destaque: 'Saúde Mental',
    },
    {
      titulo: 'Família e Amigos',
      descricao: 'Problemas financeiros e o isolamento abalam a confiança, gerando conflitos severos na convivência familiar.',
      icone: Users,
      destaque: 'Relacionamentos',
    },
    {
      titulo: 'Perda de controle',
      descricao: 'O tempo e o dinheiro despendidos em plataformas aumentam de forma silenciosa e compulsiva.',
      icone: Clock,
      destaque: 'Compulsão',
    },
    {
      titulo: 'Perdas não voltam',
      descricao: 'A falsa ilusão de "recuperar o loss" apostando novamente apenas aprofunda o prejuízo e o desespero.',
      icone: AlertOctagon,
      destaque: 'Falácia do Apostador',
    },
    {
      titulo: 'A casa sempre tem vantagem',
      descricao: 'Os algoritmos são matematicamente desenhados para garantir o lucro das bancas. No longo prazo, a perda é certa.',
      icone: Scale,
      destaque: 'Regulamentação',
    },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#14171b] text-[#f4f1ea] border-b border-[#23272d]" id="problema">
      <div className="max-w-7xl mx-auto">
        <div className="max-w-3xl mb-12">
          <p className="text-[#d8a13b] uppercase text-xs font-extrabold tracking-widest mb-2">
            O Problema Real
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold uppercase tracking-tight text-[#f4f1ea]">
            Não é apenas um jogo.
          </h2>
          <p className="text-[#a9adb6] text-lg mt-3">
            Para muitas pessoas, as apostas se transformam rapidamente em um comportamento compulsivo
            alimentado por publicidade abusiva e promessas irreais de enriquecimento.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cartoes.map((item, idx) => {
            const Icone = item.icone;
            return (
              <article
                key={idx}
                className="bg-[#0e1013] border border-[#34373b] hover:border-[#d8a13b]/60 rounded-2xl p-6 sm:p-7 transition-all duration-200 hover:-translate-y-1 hover:shadow-xl group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-[#1d2129] flex items-center justify-center text-[#d8a13b] group-hover:bg-[#d8a13b]/10 transition-colors">
                      <Icone className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-semibold text-[#8a8f99] uppercase tracking-wider bg-[#1c2027] px-2.5 py-1 rounded-full">
                      {item.destaque}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-[#d8a13b] mb-2 uppercase tracking-wide">
                    {item.titulo}
                  </h3>

                  <p className="text-[#c5c5c5] text-sm leading-relaxed">
                    {item.descricao}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#23272d] flex items-center text-xs text-[#8a8f99]">
                  <span>Ponto de alerta comunitário</span>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};
