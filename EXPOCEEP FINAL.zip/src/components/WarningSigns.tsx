import React from 'react';
import { AlertCircle, HelpCircle } from 'lucide-react';

export const WarningSigns: React.FC = () => {
  const sinais = [
    'Apostar mais dinheiro do que poderia perder.',
    'Tentar recuperar perdas financeiras apostando novamente.',
    'Esconder de familiares e amigos a frequência e valores das apostas.',
    'Pedir dinheiro emprestado ou recorrer a empréstimos para apostar.',
    'Deixar de pagar contas essenciais (aluguel, luz, comida) para continuar jogando.',
    'Pensar constantemente em palpites, odds e próximas rodadas.',
    'Tentar diminuir ou parar completamente e não conseguir.',
    'Prejudicar o rendimento nos estudos, no trabalho ou nos relacionamentos afetivos.',
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f2ede3] text-[#1c1d20] border-b border-[#ded7c8]" id="sinais">
      <div className="max-w-7xl mx-auto">
        <div className="max-w-3xl mb-12">
          <p className="text-[#e4552e] uppercase text-xs font-extrabold tracking-widest mb-2">
            Autoavaliação
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold uppercase tracking-tight text-[#1c1d20]">
            Sinais de alerta: talvez seja hora de pedir ajuda.
          </h2>
          <p className="text-[#5a5d63] text-lg mt-3">
            Estes sinais não constituem um diagnóstico clínico, mas são fortes indicativos de que a relação
            com as apostas ultrapassou o limite do entretenimento.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          {sinais.map((sinal, index) => (
            <div
              key={index}
              className="flex items-start gap-3.5 p-4 sm:p-5 bg-white rounded-xl border border-[#ded7c8] shadow-sm hover:border-[#e4552e] transition-colors"
            >
              <div className="w-7 h-7 rounded-full bg-[#e4552e]/10 text-[#e4552e] flex items-center justify-center flex-shrink-0 font-bold text-sm">
                !
              </div>
              <p className="text-sm sm:text-base font-medium text-[#2d3036] leading-relaxed">
                {sinal}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-10 p-6 bg-[#0e1013] text-[#f4f1ea] rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 border border-[#2d323a]">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#d8a13b]/20 flex items-center justify-center text-[#d8a13b] flex-shrink-0">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#d8a13b] uppercase">Identificou 1 ou mais sinais?</h3>
              <p className="text-xs sm:text-sm text-[#c5c5c5]">
                Reconhecer a dificuldade é o primeiro passo para retomar o controle de sua vida e das suas finanças.
              </p>
            </div>
          </div>

          <a
            href="#ajuda"
            className="inline-flex items-center gap-2 bg-[#d8a13b] hover:bg-[#c08d2d] text-[#0e1013] px-5 py-2.5 rounded-full font-bold text-xs uppercase tracking-wider transition-all whitespace-nowrap"
          >
            <HelpCircle className="w-4 h-4" />
            Ver canais de apoio
          </a>
        </div>
      </div>
    </section>
  );
};
