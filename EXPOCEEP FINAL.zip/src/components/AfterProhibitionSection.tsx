import React, { useState } from 'react';
import {
  Globe2,
  ShieldAlert,
  ArrowRight,
  AlertTriangle,
  Scale,
  Brain,
  EyeOff,
  Building2,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

export const AfterProhibitionSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<number>(0);

  const temas = [
    {
      id: 0,
      icone: Globe2,
      titulo: 'Sites Espelho e Mercado Ilegal',
      subtitulo: 'Migração para paraísos fiscais e domínios clones',
      resumo:
        'A proibição formal encerra a operação legalizada, mas o submundo digital responde em minutos com clones hospedados no exterior.',
      pontos: [
        'Criação automatizada de novos domínios (.vip, .bet, .top) a cada bloqueio da Anatel.',
        'Utilização de redes privadas virtuais (VPN) e aplicativos camuflados sem registro na Play Store.',
        'Falta total de auditoria: o jogador em site clandestino não tem a quem recorrer em caso de golpe ou retenção de valores.',
      ],
      alerta: 'Sem supervisão do Estado, os algoritmos clandestinos podem fraudar taxas de retorno sem nenhum limite.',
    },
    {
      id: 1,
      icone: EyeOff,
      titulo: 'Engenharia Financeira Clandestina',
      subtitulo: 'Laranjas, chaves Pix rotativas e cripto',
      resumo:
        'O fluxo de dinheiro não para apenas com a lei: redes organizadas utilizam intermediários de pagamento para mascarar as transferências.',
      pontos: [
        'Uso de CNPJs de fachada e pessoas físicas interpostas para receber depósitos imediatos via Pix.',
        'Pulverização de valores e evasão de divisas através de corretoras de criptoativos não reguladas.',
        'Cobranças violentas e surgimento de agiotagem digital quando o apostador perde o crédito bancário formal.',
      ],
      alerta: 'Quem entra no mercado clandestino fica exposto a crimes de extorsão e vazamento de dados pessoais.',
    },
    {
      id: 2,
      icone: Brain,
      titulo: 'A Saúde Mental Não se Cura por Decreto',
      subtitulo: 'O vício permanece ativo mesmo sem casas legais',
      resumo:
        'A ludopatia é reconhecida pela OMS (CID-11: 6C50) como dependência comportamental grave. Proibir não remove a abstinência.',
      pontos: [
        'A fissura (*craving*) por dopamina leva apostadores dependentes a buscar qualquer canal clandestino para jogar.',
        'O endividamento acumulado gera crises severas de ansiedade, depressão e risco de automutilação.',
        'O sentimento de vergonha e culpa impede que familiares e vítimas procurem ajuda psiquiátrica precoce.',
      ],
      alerta: 'Proibição sem suporte médico e psicológico gratuito deixa milhares de famílias desamparadas no isolamento.',
    },
    {
      id: 3,
      icone: Building2,
      titulo: 'A Urgência da Prevenção Primária',
      subtitulo: 'Por que educar é mais eficaz do que apenas punir',
      resumo:
        'A proteção duradoura da sociedade exige conscientização crítica desde o ensino fundamental e médio.',
      pontos: [
        'Educação financeira crítica: ensinar probabilidade estatística real e a desconstrução de ilusões de "renda fácil".',
        'Treinamento de professores, psicólogos escolares e equipes de saúde da família para identificar sinais precoces.',
        'Criação de redes de apoio psicossocial acessíveis através do SUS e dos CAPS em todo o país.',
      ],
      alerta: 'O projeto CEEP defende que a tecnologia deve ser usada para empoderar o cidadão com conhecimento científico.',
    },
  ];

  return (
    <section id="depois-da-proibicao" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#14171b] text-[#f4f1ea] border-b border-[#23272d]">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Cabeçalho da Seção */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-[#d8a13b]/15 text-[#d8a13b] border border-[#d8a13b]/30 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
            <Scale className="w-3.5 h-3.5" />
            Análise Científica & Pós-Proibição
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold uppercase tracking-tight text-[#f4f1ea]">
            Depois da Proibição:{' '}
            <span className="text-[#e4552e]">Onde Mora o Perigo Real?</span>
          </h2>
          <p className="text-[#a9adb6] text-base sm:text-lg leading-relaxed">
            A decisão legal de proibir apostas de quota fixa foi um marco regulatório no Brasil.
            No entanto, estudos de saúde pública e cibersegurança mostram que a proibição formal
            é apenas a primeira etapa. Conheça as quatro frentes críticas que exigem atenção continuada.
          </p>
        </div>

        {/* Grade de Navegação dos 4 Pilares */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {temas.map((tema) => {
            const Icon = tema.icone;
            const isSelected = activeTab === tema.id;
            return (
              <button
                key={tema.id}
                onClick={() => setActiveTab(tema.id)}
                className={`p-5 rounded-2xl text-left border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#1c212a] border-[#e4552e] shadow-lg shadow-orange-950/20 translate-y-[-2px]'
                    : 'bg-[#0e1013] border-[#252a32] hover:border-[#3d4452] opacity-80 hover:opacity-100'
                }`}
              >
                <div>
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 transition-colors ${
                      isSelected
                        ? 'bg-[#e4552e] text-white'
                        : 'bg-[#1a1e24] text-[#d8a13b]'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-extrabold text-sm uppercase tracking-wide text-[#f4f1ea] mb-1">
                    {tema.titulo}
                  </h3>
                  <p className="text-xs text-[#8a8f99] line-clamp-2">{tema.subtitulo}</p>
                </div>

                <div className="pt-4 flex items-center gap-1.5 text-xs font-bold text-[#d8a13b]">
                  <span>{isSelected ? 'Visualizando' : 'Explorar análise'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Painel de Detalhe Selecionado */}
        {temas[activeTab] && (
          <div className="bg-[#0e1013] border border-[#2b3039] rounded-3xl p-6 sm:p-10 relative overflow-hidden">
            <div className="max-w-4xl space-y-6">
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs font-mono font-bold bg-[#e4552e]/20 text-[#e4552e] px-3 py-1 rounded-full uppercase">
                  Pilar {activeTab + 1} de 4
                </span>
                <span className="text-xs text-[#8a8f99]">Diagnóstico ExpoCEEP</span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-black uppercase text-[#f4f1ea]">
                  {temas[activeTab].titulo}
                </h3>
                <p className="text-sm sm:text-base text-[#d8a13b] font-medium mt-1">
                  {temas[activeTab].subtitulo}
                </p>
              </div>

              <p className="text-base text-[#c5c5c5] leading-relaxed">
                {temas[activeTab].resumo}
              </p>

              {/* Lista de Pontos Analíticos */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#a9adb6]">
                  Evidências e Mecanismos Observados:
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {temas[activeTab].pontos.map((ponto, i) => (
                    <div
                      key={i}
                      className="bg-[#15181e] border border-[#23272d] p-4 rounded-xl text-xs text-[#c5c5c5] leading-relaxed space-y-2"
                    >
                      <span className="w-6 h-6 rounded-lg bg-[#23272d] text-[#d8a13b] font-mono font-bold flex items-center justify-center text-[11px]">
                        {i + 1}
                      </span>
                      <p>{ponto}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Alerta de Gravidade */}
              <div className="p-4 bg-[#1f1614] border border-[#e4552e]/40 rounded-2xl flex items-start gap-3 text-xs sm:text-sm text-[#ffb4a2]">
                <AlertTriangle className="w-5 h-5 flex-shrink-0 text-[#e4552e] mt-0.5" />
                <div>
                  <span className="font-extrabold uppercase text-[#e4552e] block mb-0.5">
                    Impacto para a Prevenção:
                  </span>
                  <p className="leading-relaxed">{temas[activeTab].alerta}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quadro Comparativo Síntese */}
        <div className="bg-[#181c23] border border-[#2d333f] rounded-2xl p-6 sm:p-8">
          <div className="max-w-4xl space-y-4">
            <h4 className="text-lg font-black uppercase text-[#f4f1ea] flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#d8a13b]" />
              A Mudança de Paradigma que o Brasil Precisa
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-[#0e1013] rounded-xl border border-[#3b2a26]">
                <span className="text-xs font-bold uppercase tracking-wider text-[#e4552e] block mb-2">
                  ❌ Apenas Modelo Punitivo / Proibicionista
                </span>
                <ul className="text-xs text-[#a9adb6] space-y-1.5 list-disc pl-4">
                  <li>Considera que o problema acaba ao desligar um site.</li>
                  <li>Trata a pessoa viciada como culpada moral em vez de paciente.</li>
                  <li>Não aborda a ilusão matemática e o viés cognitivo nas escolas.</li>
                  <li>Favorece a ida de vulneráveis para a clandestinidade.</li>
                </ul>
              </div>

              <div className="p-4 bg-[#0e1013] rounded-xl border border-[#214332]">
                <span className="text-xs font-bold uppercase tracking-wider text-[#50fa7b] block mb-2">
                  ✅ Modelo Integrado de Prevenção e Saúde (Proposta CEEP)
                </span>
                <ul className="text-xs text-[#a9adb6] space-y-1.5 list-disc pl-4">
                  <li>Bloqueio técnico aliado a acolhimento psicológico no SUS.</li>
                  <li>Educação financeira crítica e probabilidade estatística nas escolas.</li>
                  <li>Transparência com dados abertos e pesquisa contínua da sociedade.</li>
                  <li>Apoio financeiro e jurídico para famílias endividadas.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
