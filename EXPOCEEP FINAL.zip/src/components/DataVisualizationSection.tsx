import React, { useState } from 'react';
import {
  BarChart3,
  Database,
  PieChart,
  Layers,
  ArrowUpRight,
  TrendingDown,
  Sparkles,
  Users,
  ShieldCheck,
  Percent,
} from 'lucide-react';
import { EstatisticaCategoria, PesquisaEstatisticas } from '../types.ts';

interface DataVisualizationSectionProps {
  estatisticasAssinaturas: EstatisticaCategoria[];
  totalAssinaturas: number;
  estatisticasPesquisa: PesquisaEstatisticas | null;
  onOpenDatabase: () => void;
}

export const DataVisualizationSection: React.FC<DataVisualizationSectionProps> = ({
  estatisticasAssinaturas,
  totalAssinaturas,
  estatisticasPesquisa,
  onOpenDatabase,
}) => {
  const [abaAtiva, setAbaAtiva] = useState<'peticao' | 'pesquisa' | 'matematica'>('peticao');

  const getCorCategoria = (id: number) => {
    switch (id) {
      case 1:
        return { bg: 'bg-[#e4552e]', text: 'text-[#e4552e]', bar: 'bg-[#e4552e]' };
      case 2:
        return { bg: 'bg-[#d8a13b]', text: 'text-[#d8a13b]', bar: 'bg-[#d8a13b]' };
      case 3:
        return { bg: 'bg-[#2e7d5b]', text: 'text-[#2e7d5b]', bar: 'bg-[#2e7d5b]' };
      default:
        return { bg: 'bg-[#3b82f6]', text: 'text-[#3b82f6]', bar: 'bg-[#3b82f6]' };
    }
  };

  return (
    <section id="dados" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#0e1013] text-[#f4f1ea] border-b border-[#23272d]">
      <div className="max-w-7xl mx-auto space-y-10">
        {/* Cabeçalho */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <div className="flex items-center gap-2 text-[#d8a13b] text-xs font-extrabold uppercase tracking-widest">
              <BarChart3 className="w-4 h-4" />
              Ciência de Dados & Estatística • TCC ExpoCEEP
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight text-[#f4f1ea]">
              Central de Dados & Indicadores
            </h2>
            <p className="text-[#a9adb6] text-base leading-relaxed">
              Consulte a consolidação analítica do banco de dados relacional SQLite, confrontando
              as assinaturas do movimento de prevenção com a pesquisa de percepção coletiva.
            </p>
          </div>

          <button
            onClick={onOpenDatabase}
            className="inline-flex items-center gap-2 bg-[#1c2027] hover:bg-[#252b34] text-[#d8a13b] border border-[#34373b] px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all self-start md:self-auto cursor-pointer"
          >
            <Database className="w-4 h-4 text-[#d8a13b]" />
            Abrir Inspetor SQLite (DER)
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Abas do Painel */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[#23272d] pb-2 text-xs font-bold uppercase tracking-wider">
          <button
            onClick={() => setAbaAtiva('peticao')}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-2 ${
              abaAtiva === 'peticao'
                ? 'bg-[#e4552e] text-white'
                : 'bg-[#14171b] text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            1. Petição Pública (1:N)
          </button>

          <button
            onClick={() => setAbaAtiva('pesquisa')}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-2 ${
              abaAtiva === 'pesquisa'
                ? 'bg-[#e4552e] text-white'
                : 'bg-[#14171b] text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            2. Pesquisa ExpoCEEP
          </button>

          <button
            onClick={() => setAbaAtiva('matematica')}
            className={`px-4 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-2 ${
              abaAtiva === 'matematica'
                ? 'bg-[#e4552e] text-white'
                : 'bg-[#14171b] text-[#8a8f99] hover:text-[#f4f1ea]'
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5" />
            3. A Matemática da Ruína
          </button>
        </div>

        {/* ABA 1: PETIÇÃO PÚBLICA 1:N */}
        {abaAtiva === 'peticao' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {estatisticasAssinaturas.map((stat) => {
                const cores = getCorCategoria(stat.categoria_id);
                return (
                  <div
                    key={stat.categoria_id}
                    className="bg-[#14171b] border border-[#2d323a] hover:border-[#3d444f] rounded-3xl p-6 transition-all flex flex-col justify-between shadow-lg"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-[11px] font-mono text-[#8a8f99] bg-[#1d2129] px-2 py-0.5 rounded">
                          FK ID: #{stat.categoria_id}
                        </span>
                        <span className="text-xs font-bold text-[#d8a13b]">
                          {stat.porcentagem}% dos apoios
                        </span>
                      </div>

                      <h3 className="text-xl font-black text-[#f4f1ea] uppercase tracking-wide mb-1">
                        {stat.nome_alerta}
                      </h3>

                      <div className="flex items-baseline gap-2 mt-4">
                        <span className="text-4xl font-extrabold text-[#f4f1ea]">{stat.total}</span>
                        <span className="text-xs text-[#8a8f99] uppercase font-semibold">
                          apoiadores
                        </span>
                      </div>
                    </div>

                    <div className="mt-6">
                      <div className="w-full h-2.5 bg-[#23272d] rounded-full overflow-hidden">
                        <div
                          className={`h-full ${cores.bar} rounded-full transition-all duration-500`}
                          style={{ width: `${Math.max(stat.porcentagem, 4)}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Nota da Regra 1:N */}
            <div className="p-5 bg-[#171b21] border border-[#2d323a] rounded-2xl flex items-start gap-3.5 text-xs text-[#a9adb6]">
              <Layers className="w-5 h-5 text-[#d8a13b] flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-[#f4f1ea] uppercase mr-1">
                  Integridade Referencial 1:N:
                </span>
                Cada apoio na tabela <code className="text-[#d8a13b] font-mono">assinaturas</code> referencia uma categoria pré-cadastrada na tabela <code className="text-[#d8a13b] font-mono">categorias</code>. A chave estrangeira impede dados corrompidos e viabiliza a soma percentual em tempo real.
              </div>
            </div>
          </div>
        )}

        {/* ABA 2: PESQUISA EXPOCEEP */}
        {abaAtiva === 'pesquisa' && (
          <div className="space-y-6 animate-fadeIn">
            {estatisticasPesquisa ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Gráfico 1: Faixas Etárias */}
                <div className="bg-[#14171b] border border-[#2d323a] rounded-3xl p-6 space-y-4">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-[#d8a13b] flex items-center justify-between">
                    <span>Participação por Faixa Etária</span>
                    <span className="text-xs text-[#8a8f99] font-mono">
                      Total: {estatisticasPesquisa.total}
                    </span>
                  </h4>
                  <div className="space-y-3">
                    {Object.entries(estatisticasPesquisa.porFaixaEtaria).map(([faixa, count]) => {
                      const num = Number(count) || 0;
                      const pct = Math.round((num / (estatisticasPesquisa.total || 1)) * 100);
                      return (
                        <div key={faixa} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-[#c5c5c5]">{faixa}</span>
                            <span className="font-mono text-[#d8a13b] font-bold">
                              {num} ({pct}%)
                            </span>
                          </div>
                          <div className="w-full h-2 bg-[#23272d] rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#d8a13b] rounded-full"
                              style={{ width: `${pct}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Gráfico 2: Contato com Apostas */}
                <div className="bg-[#14171b] border border-[#2d323a] rounded-3xl p-6 space-y-4">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-[#e4552e]">
                    Relação Pessoal com Apostas Virtuais
                  </h4>
                  <div className="space-y-3">
                    {Object.entries(estatisticasPesquisa.porContato).map(([contato, count]) => {
                      const num = Number(count) || 0;
                      const pct = Math.round((num / (estatisticasPesquisa.total || 1)) * 100);
                      return (
                        <div key={contato} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-[#c5c5c5] truncate max-w-[240px]" title={contato}>
                              {contato}
                            </span>
                            <span className="font-mono text-[#e4552e] font-bold">
                              {num} ({pct}%)
                            </span>
                          </div>
                          <div className="w-full h-2 bg-[#23272d] rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#e4552e] rounded-full"
                              style={{ width: `${pct}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Gráfico 3: Prioridades de Ação Futura */}
                <div className="md:col-span-2 bg-[#14171b] border border-[#2d323a] rounded-3xl p-6 space-y-4">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-[#50fa7b]">
                    Prioridade Mais Votada para Políticas Públicas
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {Object.entries(estatisticasPesquisa.porAreaPrioritaria).map(([area, count]) => {
                      const num = Number(count) || 0;
                      const pct = Math.round((num / (estatisticasPesquisa.total || 1)) * 100);
                      return (
                        <div key={area} className="p-4 bg-[#0e1013] rounded-2xl border border-[#23272d] space-y-2">
                          <div className="flex justify-between text-xs font-bold">
                            <span className="text-[#f4f1ea]">{area}</span>
                            <span className="text-[#50fa7b] font-mono">{pct}%</span>
                          </div>
                          <div className="w-full h-2 bg-[#1a1e24] rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#50fa7b] rounded-full"
                              style={{ width: `${pct}%` }}
                            ></div>
                          </div>
                          <span className="text-[11px] text-[#8a8f99] block font-mono">
                            {num} votos registrados
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#8a8f99]">Carregando estatísticas da pesquisa...</p>
            )}
          </div>
        )}

        {/* ABA 3: A MATEMÁTICA DA RUÍNA */}
        {abaAtiva === 'matematica' && (
          <div className="bg-[#14171b] border border-[#2d323a] rounded-3xl p-6 sm:p-8 space-y-6 animate-fadeIn">
            <div>
              <span className="text-xs font-mono font-bold text-[#d8a13b] uppercase">
                Teorema da Ruína do Apostador (Gambler's Ruin)
              </span>
              <h3 className="text-2xl font-black uppercase text-[#f4f1ea] mt-1">
                Por Que a Banca Sempre Ganha no Longo Prazo?
              </h3>
              <p className="text-xs sm:text-sm text-[#a9adb6] mt-2 leading-relaxed max-w-3xl">
                Em qualquer jogo com margem da casa (House Edge positiva), a probabilidade acumulada de o jogador perder todo o capital aproxima-se de 100% conforme o número de jogadas cresce. Veja a comparação probabilística:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-[#0e1013] rounded-2xl border border-[#2d323a] space-y-2">
                <span className="text-xs font-bold uppercase text-[#8a8f99]">10 Apostas</span>
                <div className="text-2xl font-bold font-mono text-[#d8a13b]">~52% Chance</div>
                <p className="text-xs text-[#a9adb6]">
                  Ainda há ilusão de vitória pela alta volatilidade de curto prazo.
                </p>
              </div>

              <div className="p-4 bg-[#0e1013] rounded-2xl border border-[#2d323a] space-y-2">
                <span className="text-xs font-bold uppercase text-[#8a8f99]">100 Apostas</span>
                <div className="text-2xl font-bold font-mono text-[#ff8e7b]">~84% Perda</div>
                <p className="text-xs text-[#a9adb6]">
                  A margem matemática da banca começa a drenar o montante com clareza.
                </p>
              </div>

              <div className="p-4 bg-[#0e1013] rounded-2xl border border-[#e4552e]/50 space-y-2">
                <span className="text-xs font-bold uppercase text-[#e4552e]">1.000 Apostas</span>
                <div className="text-2xl font-bold font-mono text-[#e4552e]">99.8% Ruína</div>
                <p className="text-xs text-[#a9adb6]">
                  Estatisticamente impossível superar a casa no limite da lei dos grandes números.
                </p>
              </div>
            </div>

            <div className="p-4 bg-[#1f1715] border border-[#e4552e]/30 rounded-2xl text-xs text-[#ffb4a2] leading-relaxed">
              <strong>Conclusão Técnica do TCC:</strong> Promessas de "renda fixa com apostas" ou "trabalhar no mercado de apostas" colidem frontalmente com a teoria das probabilidades de Bernoulli e Kolmogorov. A única forma de lucro garantido é ser o dono do cassino.
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
