import React, { useState } from 'react';
import { Database, Menu, X, ShieldAlert, CheckCircle2, BookOpen, Brain, Sparkles, HelpCircle } from 'lucide-react';

interface NavbarProps {
  onOpenDatabase: () => void;
  totalAssinaturas?: number;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenDatabase, totalAssinaturas }) => {
  const [menuAberto, setMenuAberto] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#0e1013]/95 backdrop-blur-md border-b border-[#23272d] shadow-md transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Identidade */}
          <a
            href="#inicio"
            className="flex items-center gap-3 group text-[#f4f1ea] transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-[#e4552e]/15 border border-[#e4552e]/30 flex items-center justify-center text-[#e4552e] group-hover:rotate-6 transition-transform">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="font-extrabold text-lg sm:text-xl tracking-tight uppercase leading-tight">
                Brasil <span className="text-[#e4552e]">Contra</span> as Bets
              </div>
              <span className="text-[10px] text-[#d8a13b] font-bold uppercase tracking-widest block">
                Da Proibição à Prevenção • TCC ExpoCEEP
              </span>
            </div>
          </a>

          {/* Links Desktop */}
          <nav className="hidden xl:flex items-center gap-4 text-xs font-semibold uppercase tracking-wider">
            <a href="#inicio" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Início
            </a>
            <a href="#problema" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              O Problema
            </a>
            <a href="#depois-da-proibicao" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Depois da Proibição
            </a>
            <a href="#simulador" className="text-[#d8a13b] hover:text-white transition-colors flex items-center gap-1 font-bold">
              <Sparkles className="w-3 h-3 text-[#d8a13b]" />
              Simulador
            </a>
            <a href="#quiz" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Quiz
            </a>
            <a href="#mitos" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Mitos & Verdades
            </a>
            <a href="#pesquisa" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Pesquisa
            </a>
            <a href="#dados" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Dados
            </a>
            <a href="#ajuda" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Ajuda
            </a>
            <a href="#sobre" className="text-[#c5c5c5] hover:text-[#d8a13b] transition-colors">
              Sobre o Projeto
            </a>

            {/* Botão de Inspeção do Banco SQLite */}
            <button
              onClick={onOpenDatabase}
              className="inline-flex items-center gap-1.5 bg-[#1a1e24] hover:bg-[#252b33] text-[#d8a13b] border border-[#3b3f46] px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-xs cursor-pointer ml-1"
              title="Visualizar Banco de Dados SQLite, Tabelas e DER"
            >
              <Database className="w-3.5 h-3.5 text-[#d8a13b]" />
              <span>SQLite</span>
              {typeof totalAssinaturas === 'number' && (
                <span className="bg-[#e4552e] text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono">
                  {totalAssinaturas}
                </span>
              )}
            </button>

            <a
              href="#assinar"
              className="inline-flex items-center gap-1.5 bg-[#e4552e] hover:bg-[#b8431f] text-white px-3.5 py-2 rounded-full font-bold text-xs uppercase tracking-wider transition-all shadow hover:shadow-orange-950"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Apoiar
            </a>
          </nav>

          {/* Links Desktop Médio (lg até xl) */}
          <div className="hidden lg:flex xl:hidden items-center gap-3">
            <a href="#depois-da-proibicao" className="text-xs font-semibold text-[#c5c5c5] hover:text-[#d8a13b]">
              Pós-Proibição
            </a>
            <a href="#simulador" className="text-xs font-bold text-[#d8a13b] hover:text-white">
              Simulador
            </a>
            <a href="#quiz" className="text-xs font-semibold text-[#c5c5c5] hover:text-[#d8a13b]">
              Quiz
            </a>
            <a href="#pesquisa" className="text-xs font-semibold text-[#c5c5c5] hover:text-[#d8a13b]">
              Pesquisa
            </a>
            <a href="#dados" className="text-xs font-semibold text-[#c5c5c5] hover:text-[#d8a13b]">
              Dados
            </a>
            <button
              onClick={onOpenDatabase}
              className="inline-flex items-center gap-1.5 bg-[#1a1e24] text-[#d8a13b] border border-[#3b3f46] px-2.5 py-1 rounded-full text-xs font-bold"
            >
              <Database className="w-3 h-3" />
              SQLite
            </button>
            <a
              href="#assinar"
              className="bg-[#e4552e] text-white px-3 py-1.5 rounded-full font-bold text-xs uppercase"
            >
              Apoiar
            </a>
          </div>

          {/* Botão Mobile */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={onOpenDatabase}
              className="p-2 text-[#d8a13b] hover:bg-[#1a1e24] rounded-lg cursor-pointer"
              title="Banco de Dados"
            >
              <Database className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMenuAberto(!menuAberto)}
              className="p-2 text-[#f4f1ea] hover:bg-[#1a1e24] rounded-lg cursor-pointer"
              aria-label="Abrir menu"
            >
              {menuAberto ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Menu Mobile */}
      {menuAberto && (
        <div className="lg:hidden bg-[#0e1013] border-b border-[#23272d] px-5 pt-3 pb-6 space-y-2.5 max-h-[80vh] overflow-y-auto">
          <a
            href="#inicio"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Início
          </a>
          <a
            href="#problema"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            O Problema
          </a>
          <a
            href="#depois-da-proibicao"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Depois da Proibição
          </a>
          <a
            href="#simulador"
            onClick={() => setMenuAberto(false)}
            className="block text-[#d8a13b] hover:text-white py-1.5 text-sm font-bold uppercase tracking-wider flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-[#d8a13b]" />
            Simulador: Desafio dos R$100
          </a>
          <a
            href="#quiz"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Quiz do Apostador
          </a>
          <a
            href="#mitos"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Mitos e Verdades
          </a>
          <a
            href="#pesquisa"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Pesquisa ExpoCEEP
          </a>
          <a
            href="#dados"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Dados & Estatísticas
          </a>
          <a
            href="#ajuda"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Ajuda & Recursos
          </a>
          <a
            href="#sobre"
            onClick={() => setMenuAberto(false)}
            className="block text-[#c5c5c5] hover:text-[#d8a13b] py-1.5 text-sm font-semibold uppercase tracking-wider"
          >
            Sobre o Projeto (TCC ExpoCEEP)
          </a>

          <div className="pt-3 flex flex-col gap-2">
            <button
              onClick={() => {
                setMenuAberto(false);
                onOpenDatabase();
              }}
              className="w-full flex items-center justify-center gap-2 bg-[#1a1e24] text-[#d8a13b] border border-[#3b3f46] px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider"
            >
              <Database className="w-4 h-4" />
              Inspecionar Banco de Dados SQLite (3 Tabelas)
            </button>
            <a
              href="#assinar"
              onClick={() => setMenuAberto(false)}
              className="w-full text-center bg-[#e4552e] hover:bg-[#b8431f] text-white px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider"
            >
              Assinar Movimento / Petição
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

