import React from 'react';
import { HeartHandshake, PhoneCall, ExternalLink, ShieldCheck, Check } from 'lucide-react';

export const HelpSection: React.FC = () => {
  const passos = [
    'Converse abertamente com alguém de confiança da família ou amigos.',
    'Procure acolhimento profissional nos CAPS (Centros de Atenção Psicossocial).',
    'Exclua contas e desinstale aplicativos de apostas do celular.',
    'Bloqueie publicidades, canais de "influenciadores de tips" e notificações.',
    'Organize suas finanças e considere transferir a gestão de contas a alguém de confiança.',
    'Em momentos de crise emocional severa, busque o CVV pelo número 188.',
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#235f45] text-white border-b border-[#1b4b37]" id="ajuda">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Lado Esquerdo */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-xs px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
            <HeartHandshake className="w-4 h-4" />
            Caminho de Apoio e Recuperação
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold uppercase tracking-tight leading-tight">
            Você não precisa enfrentar isso sozinho.
          </h2>

          <p className="text-white/90 text-lg leading-relaxed max-w-2xl">
            A dependência de jogos (transtorno do jogo patológico) é uma condição de saúde reconhecida
            pela Organização Mundial da Saúde (OMS). Existem redes públicas gratuitas de atendimento e acolhimento humano.
          </p>

          <div className="flex flex-wrap gap-4 pt-2">
            <a
              href="https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/s/saude-mental"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-white text-[#174632] hover:bg-[#f4f1ea] px-6 py-3 rounded-full font-bold text-sm uppercase tracking-wide transition-all shadow-md"
            >
              Portal SUS Saúde Mental
              <ExternalLink className="w-4 h-4" />
            </a>

            <div className="inline-flex items-center gap-2 bg-[#174632]/80 border border-white/20 px-5 py-3 rounded-full text-xs font-semibold">
              <PhoneCall className="w-4 h-4 text-[#d8a13b]" />
              <span>CVV: ligue 188 • Disque Saúde: 136</span>
            </div>
          </div>
        </div>

        {/* Lado Direito - Caixa de Passos Práticos */}
        <div className="lg:col-span-5">
          <div className="bg-black/25 border border-white/20 rounded-2xl p-6 sm:p-8 backdrop-blur-sm shadow-xl">
            <div className="flex items-center gap-2.5 mb-4 pb-3 border-b border-white/15">
              <ShieldCheck className="w-5 h-5 text-[#d8a13b]" />
              <h3 className="text-xl font-bold uppercase tracking-wide">Passos Fundamentais</h3>
            </div>

            <ul className="space-y-3.5 text-sm text-white/90">
              {passos.map((passo, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0 text-xs font-bold text-[#d8a13b] mt-0.5">
                    <Check className="w-3 h-3" />
                  </span>
                  <span>{passo}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
