import React, { useState } from 'react';
import { Users, MessageSquare, Calendar, ShieldCheck, Filter, Heart } from 'lucide-react';
import { Assinatura, Categoria } from '../types.ts';

interface SignaturesMuralProps {
  assinaturas: Assinatura[];
  categorias: Categoria[];
}

export const SignaturesMural: React.FC<SignaturesMuralProps> = ({ assinaturas, categorias }) => {
  const [categoriaFiltro, setCategoriaFiltro] = useState<number | 'todas'>('todas');

  const assinaturasFiltradas =
    categoriaFiltro === 'todas'
      ? assinaturas
      : assinaturas.filter((a) => a.categoria_id === categoriaFiltro);

  const getBadgeStyle = (categoriaId: number) => {
    switch (categoriaId) {
      case 1:
        return 'bg-[#e4552e]/15 text-[#e4552e] border-[#e4552e]/30';
      case 2:
        return 'bg-[#d8a13b]/15 text-[#d8a13b] border-[#d8a13b]/30';
      case 3:
        return 'bg-[#2e7d5b]/15 text-[#2e7d5b] border-[#2e7d5b]/30';
      default:
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
    }
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#f2ede3] text-[#1c1d20] border-b border-[#ded7c8]" id="mural">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div>
            <span className="text-[#e4552e] uppercase text-xs font-extrabold tracking-widest block mb-2">
              Mural Comunitário
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold uppercase tracking-tight text-[#1c1d20]">
              Vozes que Fortalecem o Movimento
            </h2>
            <p className="text-[#5a5d63] text-base mt-2 max-w-xl">
              Confira os apoiadores cadastrados no banco de dados SQLite. Os dados sensíveis como CPF e e-mail são protegidos por anonimização pública.
            </p>
          </div>

          {/* Filtro por Categoria */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0">
            <span className="text-xs font-bold text-[#716c62] flex items-center gap-1 mr-1">
              <Filter className="w-3.5 h-3.5" /> Filtrar:
            </span>
            <button
              onClick={() => setCategoriaFiltro('todas')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
                categoriaFiltro === 'todas'
                  ? 'bg-[#0e1013] text-white shadow-sm'
                  : 'bg-white text-[#5a5d63] hover:bg-[#e4ddcf] border border-[#ded7c8]'
              }`}
            >
              Todos ({assinaturas.length})
            </button>
            {categorias.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategoriaFiltro(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                  categoriaFiltro === cat.id
                    ? 'bg-[#0e1013] text-white shadow-sm'
                    : 'bg-white text-[#5a5d63] hover:bg-[#e4ddcf] border border-[#ded7c8]'
                }`}
              >
                {cat.nome_alerta}
              </button>
            ))}
          </div>
        </div>

        {/* Grade de Assinaturas */}
        {assinaturasFiltradas.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-[#ded7c8]">
            <Users className="w-10 h-10 text-[#a39c8e] mx-auto mb-3" />
            <p className="text-base font-bold text-[#34373b]">Nenhuma assinatura nesta categoria ainda.</p>
            <p className="text-xs text-[#716c62] mt-1">Seja o primeiro a assinar sob este motivo!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {assinaturasFiltradas.map((item) => (
              <article
                key={item.id}
                className="bg-white rounded-2xl border border-[#ded7c8] p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-full bg-[#1c1d20] text-white font-bold flex items-center justify-center text-xs">
                        {item.nome_publico ? item.nome_publico.substring(0, 2).toUpperCase() : 'AP'}
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-[#1c1d20] flex items-center gap-1.5">
                          {item.nome_publico || item.nome_completo}
                          <ShieldCheck className="w-3.5 h-3.5 text-[#2e7d5b]" title="Assinatura Verificada" />
                        </h3>
                        <p className="text-[11px] font-mono text-[#7a756c]">{item.cpf_mascarado}</p>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border ${getBadgeStyle(
                        item.categoria_id
                      )}`}
                    >
                      {item.categoria_nome || 'Apoio Geral'}
                    </span>
                  </div>

                  {item.comentario ? (
                    <div className="mt-3 p-3 bg-[#f7f5f0] rounded-xl border border-[#ede7db] text-xs text-[#3f4147] italic flex items-start gap-2 leading-relaxed">
                      <MessageSquare className="w-3.5 h-3.5 text-[#e4552e] flex-shrink-0 mt-0.5" />
                      <span>"{item.comentario}"</span>
                    </div>
                  ) : (
                    <p className="mt-3 text-xs text-[#8a867c] italic">
                      "Assinou a favor da conscientização e regulamentação das apostas."
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-[#f0eae0] flex items-center justify-between text-[11px] text-[#8a867c]">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-[#a09a8e]" />
                    {item.data_registro ? item.data_registro.split(' ')[0] : '2026'}
                  </span>
                  <span className="font-mono text-[10px] text-[#b0aaa0]">ID #{item.id}</span>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
