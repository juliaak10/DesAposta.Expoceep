import React from 'react';
import { ShieldAlert, Database, HeartHandshake } from 'lucide-react';

interface FooterProps {
  onOpenDatabase: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenDatabase }) => {
  return (
    <footer className="bg-[#08090b] text-[#a9adb6] py-16 px-4 sm:px-6 lg:px-8 border-t border-[#1a1d22]">
      <div className="max-w-7xl mx-auto flex flex-col items-center text-center space-y-6">
        {/* Logo */}
        <div className="flex flex-col items-center gap-1">
          <div className="flex items-center gap-2 text-[#f4f1ea] font-extrabold text-2xl tracking-wider uppercase">
            <ShieldAlert className="w-6 h-6 text-[#e4552e]" />
            <span>
              Brasil <span className="text-[#e4552e]">Contra</span> as Bets
            </span>
          </div>
          <span className="text-xs text-[#d8a13b] font-bold uppercase tracking-widest">
            Da Proibição à Prevenção • TCC ExpoCEEP
          </span>
        </div>

        <p className="text-base text-[#c5c5c5] max-w-xl">
          Informação, acolhimento e conscientização também são formas essenciais de proteção coletiva.
        </p>

        {/* Links Rápidos */}
        <div className="flex flex-wrap justify-center gap-4 sm:gap-6 text-xs uppercase tracking-wider font-semibold text-[#8a8f99]">
          <a href="#problema" className="hover:text-[#d8a13b] transition">
            O Problema
          </a>
          <a href="#depois-da-proibicao" className="hover:text-[#d8a13b] transition">
            Pós-Proibição
          </a>
          <a href="#simulador" className="hover:text-[#d8a13b] transition">
            Simulador
          </a>
          <a href="#quiz" className="hover:text-[#d8a13b] transition">
            Quiz
          </a>
          <a href="#mitos" className="hover:text-[#d8a13b] transition">
            Mitos & Verdades
          </a>
          <a href="#pesquisa" className="hover:text-[#d8a13b] transition">
            Pesquisa ExpoCEEP
          </a>
          <a href="#dados" className="hover:text-[#d8a13b] transition">
            Dados
          </a>
          <a href="#ajuda" className="hover:text-[#d8a13b] transition">
            Ajuda
          </a>
          <a href="#sobre" className="hover:text-[#d8a13b] transition">
            Sobre o Projeto
          </a>
          <button onClick={onOpenDatabase} className="hover:text-[#d8a13b] transition flex items-center gap-1 cursor-pointer">
            <Database className="w-3.5 h-3.5 text-[#d8a13b]" /> Inspetor SQLite
          </button>
        </div>

        {/* Divisor */}
        <div className="w-full max-w-2xl h-px bg-[#1d2129]"></div>

        {/* Créditos Acadêmicos do Projeto */}
        <div className="text-xs space-y-1 text-[#717682]">
          <p className="font-semibold text-[#8a8f99]">
            PROJETO: CEEP Contra as BETS • Turma 3M - Desenvolvimento de Sistemas
          </p>
          <p>
            Equipe: Gabriely Martins Cabral, Julia Augusta do Espírito Santo Nicolack e Rafael Bertoldo Varela
          </p>
          <p className="text-[11px] text-[#555a64] pt-1">
            Modelagem Relacional 1:N com SQLite (<code className="font-mono text-[#d8a13b]/80">categorias</code> e <code className="font-mono text-[#d8a13b]/80">assinaturas</code>) e API RESTful integrada.
          </p>
        </div>

        <p className="text-[11px] text-[#555a64] max-w-lg">
          Este site tem finalidade estritamente pedagógica, social e informativa, não substituindo orientação médica, psicológica ou jurídica profissional.
        </p>

        <p className="text-[11px] text-[#444852]">
          © 2026 Brasil Contra as Bets / CEEP • Todos os direitos reservados.
        </p>
      </div>
    </footer>
  );
};
