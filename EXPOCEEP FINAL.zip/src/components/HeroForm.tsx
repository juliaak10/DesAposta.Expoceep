import React, { useState } from 'react';
import { ShieldAlert, Users, CheckCircle2, AlertTriangle, ArrowRight, Loader2, Sparkles } from 'lucide-react';
import { Categoria } from '../types.ts';
import { formatarCpf, validarCpf } from '../utils/cpf.ts';

interface HeroFormProps {
  categorias: Categoria[];
  totalAssinaturas: number;
  onAssinaturaCadastrada: () => void;
  onOpenDatabase: () => void;
}

export const HeroForm: React.FC<HeroFormProps> = ({
  categorias,
  totalAssinaturas,
  onAssinaturaCadastrada,
  onOpenDatabase,
}) => {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [cpf, setCpf] = useState('');
  const [categoriaId, setCategoriaId] = useState<string>('');
  const [comentario, setComentario] = useState('');

  const [enviando, setEnviando] = useState(false);
  const [mensagemSucesso, setMensagemSucesso] = useState<string | null>(null);
  const [mensagemErro, setMensagemErro] = useState<string | null>(null);

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatado = formatarCpf(e.target.value);
    setCpf(formatado);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMensagemErro(null);
    setMensagemSucesso(null);

    // Validações locais
    if (!nome.trim() || !email.trim() || !cpf.trim() || !categoriaId) {
      setMensagemErro('Por favor, preencha todos os campos obrigatórios (Nome, E-mail, CPF e Motivo de Alerta).');
      return;
    }

    const validacaoCpf = validarCpf(cpf);
    if (!validacaoCpf.valido) {
      setMensagemErro(validacaoCpf.motivo || 'CPF inválido.');
      return;
    }

    setEnviando(true);

    try {
      const response = await fetch('/api/assinaturas', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nome_completo: nome.trim(),
          email: email.trim().toLowerCase(),
          cpf: cpf.trim(),
          categoria_id: Number(categoriaId),
          comentario: comentario.trim() || undefined,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.sucesso) {
        throw new Error(data.mensagem || 'Não foi possível registrar sua assinatura.');
      }

      setMensagemSucesso(data.mensagem || 'Assinatura confirmada e gravada com sucesso no banco de dados SQLite!');
      setNome('');
      setEmail('');
      setCpf('');
      setCategoriaId('');
      setComentario('');
      onAssinaturaCadastrada();
    } catch (err: any) {
      setMensagemErro(err.message || 'Falha na conexão com o servidor. Verifique o banco de dados.');
    } finally {
      setEnviando(false);
    }
  };

  return (
    <section
      id="inicio"
      className="relative overflow-hidden bg-gradient-to-br from-[#1d2129] via-[#14171b] to-[#0e1013] text-[#f4f1ea] py-16 md:py-24 px-4 sm:px-6 lg:px-8 border-b border-[#23272d]"
    >
      {/* Detalhes sutis de background */}
      <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#e4552e_1px,transparent_1px)] [background-size:24px_24px]"></div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        {/* Coluna Esquerda - Texto */}
        <div className="lg:col-span-7 space-y-6">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 bg-[#e4552e]/20 text-[#e4552e] border border-[#e4552e]/40 px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest">
              <ShieldAlert className="w-3.5 h-3.5" />
              Da Proibição à Prevenção
            </span>
            <span className="inline-flex items-center gap-1 bg-[#23272d] text-[#d8a13b] px-2.5 py-1 rounded-full text-xs font-mono font-bold">
              TCC ExpoCEEP • Turma 3M
            </span>
            <span className="inline-flex items-center gap-1 bg-[#1a1e24] text-[#a9adb6] px-2.5 py-1 rounded-full text-xs font-mono">
              SQLite 1:N
            </span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight uppercase leading-[1.12] text-[#f4f1ea]">
            As bets foram proibidas.{' '}
            <span className="text-[#e4552e] block sm:inline">Mas o problema também acabou?</span>
          </h1>

          <p className="text-base sm:text-lg text-[#c5c5c5] max-w-2xl leading-relaxed">
            O cenário das apostas no Brasil mudou. Agora, o desafio é entender os impactos das apostas,
            reconhecer comportamentos de risco, compreender os desafios das operações ilegais e investigar
            o papel da prevenção e da educação.
          </p>

          {/* 3 Botões Principais Requisitados */}
          <div className="flex flex-wrap gap-3 pt-1">
            <a
              href="#depois-da-proibicao"
              className="inline-flex items-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] text-white px-5 py-3 rounded-full font-extrabold text-xs uppercase tracking-wider transition-all shadow-md hover:shadow-orange-950 cursor-pointer"
            >
              Entender o Problema
              <ArrowRight className="w-4 h-4" />
            </a>

            <a
              href="#quiz"
              className="inline-flex items-center gap-2 bg-[#1a1e24] hover:bg-[#252b33] text-[#d8a13b] border border-[#3b3f46] px-5 py-3 rounded-full font-extrabold text-xs uppercase tracking-wider transition-all shadow-xs cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#d8a13b]" />
              Testar Meus Conhecimentos
            </a>

            <a
              href="#pesquisa"
              className="inline-flex items-center gap-2 bg-[#235f45] hover:bg-[#1a4a35] text-white px-5 py-3 rounded-full font-extrabold text-xs uppercase tracking-wider transition-all shadow-xs cursor-pointer"
            >
              Participar da Pesquisa
            </a>
          </div>

          {/* Badge de Assinaturas e Apoiadores em Tempo Real */}
          <div className="pt-2 flex flex-wrap items-center gap-4">
            <div className="inline-flex items-center gap-3 bg-[#0e1013]/90 border border-[#34373b] px-4 py-2.5 rounded-xl shadow-inner">
              <div className="w-9 h-9 rounded-lg bg-[#e4552e]/20 flex items-center justify-center text-[#e4552e]">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-2xl font-black text-[#f4f1ea]">{totalAssinaturas}</span>
                  <span className="text-xs uppercase tracking-wider text-[#d8a13b] font-bold">apoiadores</span>
                </div>
                <p className="text-xs text-[#a9adb6]">registrados no banco de dados SQLite</p>
              </div>
            </div>

            <button
              onClick={onOpenDatabase}
              className="inline-flex items-center gap-2 text-xs font-semibold text-[#d8a13b] hover:text-[#f4f1ea] underline underline-offset-4 decoration-[#d8a13b]/50 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#d8a13b]" />
              Ver tabela e cardinalidade 1:N no DER
            </button>
          </div>
        </div>

        {/* Coluna Direita - Formulário Conectado ao Banco */}
        <div className="lg:col-span-5" id="assinar">
          <div className="bg-[#f2ede3] text-[#1c1d20] border-t-4 border-[#e4552e] rounded-2xl p-6 sm:p-8 shadow-2xl transition-all">
            <div className="mb-5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#e4552e] bg-[#e4552e]/10 px-2 py-0.5 rounded">
                Petição Pública Oficial
              </span>
              <h2 className="text-2xl sm:text-3xl font-black uppercase text-[#1c1d20] mt-1">
                Assine este movimento
              </h2>
              <p className="text-sm text-[#5a5d63] mt-1">
                Seu apoio é armazenado de forma segura na tabela <code className="text-xs bg-[#e5dfd3] px-1 py-0.5 rounded text-[#1c1d20] font-mono">assinaturas</code> vinculada à chave estrangeira.
              </p>
            </div>

            {/* Alerta de Sucesso */}
            {mensagemSucesso && (
              <div className="mb-4 p-3.5 bg-[#e8f5e9] border border-[#2e7d5b] text-[#1b5e20] rounded-xl text-sm flex items-start gap-2.5 animate-fadeIn">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-[#2e7d5b] mt-0.5" />
                <div>
                  <p className="font-bold">Assinatura Realizada!</p>
                  <p className="text-xs mt-0.5">{mensagemSucesso}</p>
                </div>
              </div>
            )}

            {/* Alerta de Erro */}
            {mensagemErro && (
              <div className="mb-4 p-3.5 bg-[#ffebee] border border-[#e4552e] text-[#b71c1c] rounded-xl text-sm flex items-start gap-2.5 animate-fadeIn">
                <AlertTriangle className="w-5 h-5 flex-shrink-0 text-[#e4552e] mt-0.5" />
                <div>
                  <p className="font-bold">Atenção ao preencher</p>
                  <p className="text-xs mt-0.5">{mensagemErro}</p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Nome Completo */}
              <div>
                <label htmlFor="nomeCompleto" className="block text-xs font-bold uppercase tracking-wider text-[#34373b] mb-1">
                  Nome Completo <span className="text-[#e4552e]">*</span>
                </label>
                <input
                  type="text"
                  id="nomeCompleto"
                  name="nomeCompleto"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Ex: Gabriely Martins Cabral"
                  required
                  className="w-full px-3.5 py-2.5 bg-white border border-[#c9c1b2] rounded-xl text-sm text-[#1c1d20] placeholder-[#8d887d] focus:outline-none focus:ring-2 focus:ring-[#e4552e] transition"
                />
              </div>

              {/* E-mail */}
              <div>
                <label htmlFor="email" className="block text-xs font-bold uppercase tracking-wider text-[#34373b] mb-1">
                  E-mail <span className="text-[#e4552e]">*</span>{' '}
                  <span className="text-[10px] font-normal text-[#666]">(único por apoiador)</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seuemail@exemplo.com"
                  required
                  className="w-full px-3.5 py-2.5 bg-white border border-[#c9c1b2] rounded-xl text-sm text-[#1c1d20] placeholder-[#8d887d] focus:outline-none focus:ring-2 focus:ring-[#e4552e] transition"
                />
              </div>

              {/* CPF e Categoria de Alerta em 2 Colunas */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* CPF */}
                <div>
                  <label htmlFor="cpf" className="block text-xs font-bold uppercase tracking-wider text-[#34373b] mb-1">
                    CPF <span className="text-[#e4552e]">*</span>
                  </label>
                  <input
                    type="text"
                    id="cpf"
                    name="cpf"
                    value={cpf}
                    onChange={handleCpfChange}
                    maxLength={14}
                    placeholder="000.000.000-00"
                    required
                    className="w-full px-3.5 py-2.5 bg-white border border-[#c9c1b2] rounded-xl text-sm text-[#1c1d20] placeholder-[#8d887d] focus:outline-none focus:ring-2 focus:ring-[#e4552e] font-mono transition"
                  />
                  <span className="text-[10px] text-[#6b675e] mt-0.5 block">Protegido por unicidade</span>
                </div>

                {/* Motivo de Alerta (1:N com Tabela Categorias) */}
                <div>
                  <label htmlFor="categoria_id" className="block text-xs font-bold uppercase tracking-wider text-[#34373b] mb-1">
                    Motivo de Alerta <span className="text-[#e4552e]">*</span>
                  </label>
                  <select
                    id="categoria_id"
                    name="categoria_id"
                    value={categoriaId}
                    onChange={(e) => setCategoriaId(e.target.value)}
                    required
                    className="w-full px-3 py-2.5 bg-white border border-[#c9c1b2] rounded-xl text-sm text-[#1c1d20] focus:outline-none focus:ring-2 focus:ring-[#e4552e] transition"
                  >
                    <option value="">Selecione o motivo...</option>
                    {categorias.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.nome_alerta}
                      </option>
                    ))}
                  </select>
                  <span className="text-[10px] text-[#6b675e] mt-0.5 block">FK categoria_id (1:N)</span>
                </div>
              </div>

              {/* Comentário / Depoimento Opcional */}
              <div>
                <label htmlFor="comentario" className="block text-xs font-bold uppercase tracking-wider text-[#34373b] mb-1">
                  Depoimento ou Comentário <span className="text-[10px] font-normal text-[#666]">(opcional)</span>
                </label>
                <textarea
                  id="comentario"
                  name="comentario"
                  value={comentario}
                  onChange={(e) => setComentario(e.target.value)}
                  rows={2}
                  placeholder="Por que você apoia a conscientização contra as apostas virtuais?"
                  className="w-full px-3.5 py-2 bg-white border border-[#c9c1b2] rounded-xl text-sm text-[#1c1d20] placeholder-[#8d887d] focus:outline-none focus:ring-2 focus:ring-[#e4552e] transition resize-none"
                />
              </div>

              {/* Botão de Envio */}
              <button
                type="submit"
                disabled={enviando}
                id="btnAssinar"
                className="w-full flex items-center justify-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] active:bg-[#9c3617] text-white py-3 px-6 rounded-full font-bold text-sm uppercase tracking-wider transition-all shadow-md disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
              >
                {enviando ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Gravando no SQLite...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    Quero assinar a petição
                  </>
                )}
              </button>

              <div className="flex items-center justify-between text-[11px] text-[#716c62] pt-1">
                <span>🔒 Dados protegidos & anonimizados</span>
                <span>Tabela SQLite: <span className="font-mono font-semibold">assinaturas</span></span>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
