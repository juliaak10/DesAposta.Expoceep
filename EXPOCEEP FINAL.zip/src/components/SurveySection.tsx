import React, { useState } from 'react';
import {
  ClipboardCheck,
  CheckCircle2,
  AlertTriangle,
  Send,
  Loader2,
  BarChart2,
  Users,
  Vote,
  Sparkles,
} from 'lucide-react';
import { PesquisaEstatisticas } from '../types.ts';

interface SurveySectionProps {
  estatisticasPesquisa: PesquisaEstatisticas | null;
  onRespostaEnviada: () => void;
}

export const SurveySection: React.FC<SurveySectionProps> = ({
  estatisticasPesquisa,
  onRespostaEnviada,
}) => {
  const [faixaEtaria, setFaixaEtaria] = useState('');
  const [contatoApostas, setContatoApostas] = useState('');
  const [proibicaoSuficiente, setProibicaoSuficiente] = useState('');
  const [areaPrioritaria, setAreaPrioritaria] = useState('');

  const [enviando, setEnviando] = useState(false);
  const [sucesso, setSucesso] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErro(null);

    if (!faixaEtaria || !contatoApostas || !proibicaoSuficiente || !areaPrioritaria) {
      setErro('Por favor, responda às 4 perguntas da enquete para registrar sua opinião.');
      return;
    }

    setEnviando(true);

    try {
      const res = await fetch('/api/pesquisa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          faixa_etaria: faixaEtaria,
          contato_apostas: contatoApostas,
          proibicao_suficiente: proibicaoSuficiente,
          area_prioritaria: areaPrioritaria,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.sucesso) {
        throw new Error(data.mensagem || 'Falha ao registrar sua resposta.');
      }

      setSucesso(true);
      onRespostaEnviada();
    } catch (err: any) {
      setErro(err.message || 'Erro ao conectar ao servidor SQLite.');
    } finally {
      setEnviando(false);
    }
  };

  return (
    <section id="pesquisa" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#14171b] text-[#f4f1ea] border-b border-[#23272d]">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Cabeçalho */}
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-[#2e7d5b]/20 text-[#50fa7b] border border-[#2e7d5b]/40 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
            <Vote className="w-3.5 h-3.5" />
            Enquete Sociológica • ExpoCEEP
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight text-[#f4f1ea]">
            Pesquisa ExpoCEEP:{' '}
            <span className="text-[#e4552e]">A Voz da Sociedade</span>
          </h2>
          <p className="text-[#a9adb6] text-base sm:text-lg leading-relaxed">
            Como alunos de Desenvolvimento de Sistemas, coletamos dados anônimos para alimentar
            nosso modelo estatístico sobre a percepção pública acerca do impacto das apostas e da transição
            pós-proibição. Participe e veja os resultados em tempo real!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Formulário da Enquete */}
          <div className="lg:col-span-7">
            <div className="bg-[#0e1013] border-2 border-[#282d36] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
              <div className="flex items-center justify-between border-b border-[#23272d] pb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#d8a13b] flex items-center gap-2">
                  <ClipboardCheck className="w-4 h-4" />
                  Questionário Anônimo (4 Questões)
                </span>
                <span className="text-xs text-[#8a8f99] font-mono">SQLite persistente</span>
              </div>

              {sucesso ? (
                <div className="p-8 bg-[#122218] border border-[#2e7d5b] rounded-2xl text-center space-y-4 animate-fadeIn">
                  <div className="w-12 h-12 rounded-full bg-[#2e7d5b]/20 text-[#50fa7b] flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-2xl font-black uppercase text-[#f4f1ea]">
                    Obrigado pela sua contribuição!
                  </h3>
                  <p className="text-sm text-[#a9adb6] max-w-md mx-auto leading-relaxed">
                    Sua resposta foi gravada na tabela <code className="text-[#d8a13b] font-mono">pesquisa_respostas</code> do banco de dados SQLite e já foi contabilizada nos gráficos estatísticos.
                  </p>
                  <a
                    href="#dados"
                    className="inline-flex items-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] text-white px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider transition"
                  >
                    <BarChart2 className="w-4 h-4" />
                    Ver Gráficos em Tempo Real
                  </a>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {erro && (
                    <div className="p-3 bg-[#2b1717] border border-[#e4552e] text-[#ff8e7b] rounded-xl text-xs flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                      <span>{erro}</span>
                    </div>
                  )}

                  {/* 1. Faixa Etária */}
                  <div className="space-y-2">
                    <label className="block text-xs font-extrabold uppercase tracking-wider text-[#d8a13b]">
                      1. Qual é a sua faixa etária? <span className="text-[#e4552e]">*</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {['Menor de 18 anos', '18-24 anos', '25-39 anos', '40 anos ou mais'].map((faixa) => (
                        <button
                          key={faixa}
                          type="button"
                          onClick={() => setFaixaEtaria(faixa)}
                          className={`p-3 rounded-xl border text-xs font-semibold text-center transition-all cursor-pointer ${
                            faixaEtaria === faixa
                              ? 'bg-[#e4552e] border-[#e4552e] text-white'
                              : 'bg-[#14171b] border-[#252b33] text-[#c5c5c5] hover:border-[#3d4554]'
                          }`}
                        >
                          {faixa}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 2. Relação com Apostas */}
                  <div className="space-y-2">
                    <label className="block text-xs font-extrabold uppercase tracking-wider text-[#d8a13b]">
                      2. Qual é a sua relação ou experiência com apostas virtuais? <span className="text-[#e4552e]">*</span>
                    </label>
                    <div className="space-y-2">
                      {[
                        'Nunca apostei',
                        'Já apostei recreativamente',
                        'Já tive prejuízo financeiro relevante',
                        'Conheço amigos/parentes endividados',
                      ].map((op) => (
                        <button
                          key={op}
                          type="button"
                          onClick={() => setContatoApostas(op)}
                          className={`w-full p-3 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer flex items-center justify-between ${
                            contatoApostas === op
                              ? 'bg-[#1a232f] border-[#d8a13b] text-[#f4f1ea]'
                              : 'bg-[#14171b] border-[#252b33] text-[#a9adb6] hover:border-[#3d4554]'
                          }`}
                        >
                          <span>{op}</span>
                          {contatoApostas === op && <CheckCircle2 className="w-4 h-4 text-[#d8a13b]" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 3. Percepção da Proibição */}
                  <div className="space-y-2">
                    <label className="block text-xs font-extrabold uppercase tracking-wider text-[#d8a13b]">
                      3. Em sua opinião, a proibição recente das apostas foi suficiente para encerrar o problema? <span className="text-[#e4552e]">*</span>
                    </label>
                    <div className="space-y-2">
                      {[
                        'Sim, a proibição resolveu o problema',
                        'Não, migrou para sites clandestinos',
                        'Não, falta suporte à saúde mental',
                      ].map((op) => (
                        <button
                          key={op}
                          type="button"
                          onClick={() => setProibicaoSuficiente(op)}
                          className={`w-full p-3 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer flex items-center justify-between ${
                            proibicaoSuficiente === op
                              ? 'bg-[#1a232f] border-[#d8a13b] text-[#f4f1ea]'
                              : 'bg-[#14171b] border-[#252b33] text-[#a9adb6] hover:border-[#3d4554]'
                          }`}
                        >
                          <span>{op}</span>
                          {proibicaoSuficiente === op && <CheckCircle2 className="w-4 h-4 text-[#d8a13b]" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 4. Área Prioritária */}
                  <div className="space-y-2">
                    <label className="block text-xs font-extrabold uppercase tracking-wider text-[#d8a13b]">
                      4. Qual ação deve ser a prioridade número 1 daqui para frente? <span className="text-[#e4552e]">*</span>
                    </label>
                    <div className="space-y-2">
                      {[
                        'Educação financeira e prevenção nas escolas',
                        'Bloqueio técnico rigoroso de plataformas ilegais',
                        'Centros de acolhimento e terapia pelo SUS',
                        'Apoio e renegociação para famílias endividadas',
                      ].map((op) => (
                        <button
                          key={op}
                          type="button"
                          onClick={() => setAreaPrioritaria(op)}
                          className={`w-full p-3 rounded-xl border text-xs font-medium text-left transition-all cursor-pointer flex items-center justify-between ${
                            areaPrioritaria === op
                              ? 'bg-[#1a232f] border-[#d8a13b] text-[#f4f1ea]'
                              : 'bg-[#14171b] border-[#252b33] text-[#a9adb6] hover:border-[#3d4554]'
                          }`}
                        >
                          <span>{op}</span>
                          {areaPrioritaria === op && <CheckCircle2 className="w-4 h-4 text-[#d8a13b]" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Botão Enviar */}
                  <button
                    type="submit"
                    disabled={enviando}
                    className="w-full flex items-center justify-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] active:bg-[#9c3617] text-white py-3 px-6 rounded-full font-bold text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer disabled:opacity-60"
                  >
                    {enviando ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Gravando no SQLite...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        Enviar Minha Opinião para a Pesquisa
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Painel Lateral: Métricas Rápidas da Amostra */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#0e1013] border border-[#2b3039] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#d8a13b]/20 text-[#d8a13b] flex items-center justify-center">
                  <BarChart2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#f4f1ea] uppercase">
                    Amostragem em Tempo Real
                  </h3>
                  <p className="text-xs text-[#8a8f99]">Base de dados SQLite: ExpoCEEP</p>
                </div>
              </div>

              {/* Contagem Total */}
              <div className="p-4 bg-[#14171b] rounded-2xl border border-[#23272d] flex items-center justify-between">
                <div>
                  <span className="text-xs text-[#8a8f99] block">Total de Respostas Coletadas</span>
                  <span className="text-3xl font-black font-mono text-[#50fa7b]">
                    {estatisticasPesquisa?.total || 0}
                  </span>
                </div>
                <Users className="w-8 h-8 text-[#8a8f99]" />
              </div>

              {/* Percepção sobre a Proibição */}
              {estatisticasPesquisa && (
                <div className="space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#a9adb6] block">
                    A proibição foi suficiente?
                  </span>
                  <div className="space-y-2">
                    {Object.entries(estatisticasPesquisa.porProibicao).map(([chave, qtd]) => {
                      const total = estatisticasPesquisa.total || 1;
                      const numQtd = Number(qtd) || 0;
                      const pct = Math.round((numQtd / total) * 100);
                      return (
                        <div key={chave} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-[#c5c5c5] truncate max-w-[220px]" title={chave}>
                              {chave}
                            </span>
                            <span className="font-mono text-[#d8a13b] font-bold">
                              {numQtd} ({pct}%)
                            </span>
                          </div>
                          <div className="w-full h-2 bg-[#1a1e24] rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#e4552e] rounded-full transition-all"
                              style={{ width: `${pct}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Recados da Feira */}
              <div className="p-4 bg-[#14171b] rounded-2xl border border-[#23272d] text-xs text-[#8a8f99] space-y-1">
                <span className="text-[#f4f1ea] font-bold block uppercase text-[10px]">
                  Finalidade Acadêmica:
                </span>
                <p>
                  Os dados são utilizados na análise comparativa do TCC da turma 3M, demonstrando como a sociedade percebe a diferença entre medidas repressivas e medidas preventivas.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
