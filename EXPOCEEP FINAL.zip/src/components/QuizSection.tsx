import React, { useState } from 'react';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Sparkles,
  Award,
  ChevronRight,
  Brain,
  ShieldCheck,
  Share2,
} from 'lucide-react';

interface Pergunta {
  id: number;
  enunciado: string;
  opcoes: string[];
  correta: number;
  explicacao: string;
  categoria: string;
}

export const QuizSection: React.FC = () => {
  const perguntas: Pergunta[] = [
    {
      id: 1,
      categoria: 'Matemática e Probabilidade',
      enunciado:
        'Se uma roleta virtual resultou em número vermelho 5 vezes seguidas, qual é a chance real de sair preto na 6ª rodada?',
      opcoes: [
        'Muito maior, pois a roleta precisa equilibrar as cores.',
        'A mesma probabilidade de sempre (aproximadamente 48,6% em roletas padrão com o zero), pois cada giro é um evento estatisticamente independente.',
        'Praticamente 100%, pois o algoritmo é obrigado a alternar.',
        'Depende do horário e do histórico do jogador na plataforma.',
      ],
      correta: 1,
      explicacao:
        'Essa é a famosa "Falácia do Apostador" (*Gambler\'s Fallacy*). A roleta não possui memória. Cada evento probabilístico é rigorosamente independente dos anteriores.',
    },
    {
      id: 2,
      categoria: 'Mecânica do Algoritmo',
      enunciado:
        'Em jogos como o "Tigrinho" ou caça-níqueis virtuais, o que significa a sigla RTP de 92% a 96%?',
      opcoes: [
        'Que se você colocar R$ 100,00 tem garantia de sair com no mínimo R$ 92,00.',
        'Que você tem 92% de chance de vencer em cada rodada que jogar.',
        'Que, no limite matemático de milhões de giros, o algoritmo retém entre 4% e 8% de todo o dinheiro apostado para a banca.',
        'Que o jogo só paga bônus após 92 minutos de uso contínuo.',
      ],
      correta: 2,
      explicacao:
        'RTP (*Return to Player*) é uma métrica estatística de longo prazo calculada sobre milhões de apostas. A diferença (4% a 8%) é a vantagem garantida da casa (*House Edge*), assegurando lucro perpétuo à empresa.',
    },
    {
      id: 3,
      categoria: 'Neurociência e Psicologia',
      enunciado:
        'Por que o cérebro humano libera altas doses de dopamina mesmo em rodadas onde o apostador perde dinheiro?',
      opcoes: [
        'Porque o cérebro reage ao estresse químico da perda com calma.',
        'Pelo efeito do reforço intermitente e quase-vitórias (*near-miss*), onde sons e luzes comemoram perdas disfarçadas de ganho.',
        'Porque a dopamina só é produzida quando o jogador ganha valores altos.',
        'Porque o corpo não percebe o dinheiro digital como valor real.',
      ],
      correta: 1,
      explicacao:
        'A psicologia comportamental (estudada por B.F. Skinner) comprovou que recompensas imprevisíveis e "quase-vitórias" estimulam o sistema de recompensa límbico de forma mais intensa do que vitórias fáceis, gerando compulsão.',
    },
    {
      id: 4,
      categoria: 'Saúde Mental & Sociedade',
      enunciado:
        'Por que a proibição legal recente das apostas de quota fixa no Brasil não é suficiente por si só para resolver o problema?',
      opcoes: [
        'Porque a lei não é conhecida pelos jogadores.',
        'Porque o transtorno do jogo compulsivo (ludopatia) é uma doença que exige acolhimento de saúde mental e o mercado clandestino persiste na internet.',
        'Porque as pessoas preferem pagar multas a parar de jogar.',
        'Porque não existem leis no ambiente virtual.',
      ],
      correta: 1,
      explicacao:
        'A ludopatia (CID-11: 6C50) é um transtorno neuropsiquiátrico. Pessoas adictas continuam em sofrimento sem atendimento no SUS/CAPS e podem migrar para sites clandestinos e ilegais sem prevenção primária.',
    },
    {
      id: 5,
      categoria: 'Acolhimento e Prevenção',
      enunciado:
        'Se você notar que um amigo ou familiar está pegando empréstimos, escondendo o celular e irritado por causa de apostas, qual é o caminho mais recomendado?',
      opcoes: [
        'Emprestar dinheiro para ele quitar a dívida e nunca mais jogar.',
        'Acolher sem julgamentos moralistas, incentivar a autoexclusão e orientar a busca por apoio especializado (como CAPS, CVV 188 ou Jogadores Anônimos).',
        'Ignorar o assunto, pois cada um cuida das próprias finanças.',
        'Dizer que ele precisa de mais força de vontade para parar sozinho.',
      ],
      correta: 1,
      explicacao:
        'Emprestar dinheiro agrava o ciclo de *chasing losses*. O suporte deve focar em acolhimento emocional e encaminhamento para profissionais de saúde mental e grupos de apoio mútuo.',
    },
    {
      id: 6,
      categoria: 'Segurança Digital e Golpes',
      enunciado:
        'O que realmente acontece quando um influenciador vende "robôs de sinais" ou "estratégia infalível" na internet?',
      opcoes: [
        'Ele decodificou a inteligência artificial do cassino.',
        'Ele é afiliado da plataforma e lucra uma porcentagem das perdas financeiras geradas pelas pessoas que seguem seu link.',
        'Ele tem um contrato formal de consultoria com a empresa de jogos.',
        'O robô prevê com exatidão matemática o gerador de números aleatórios.',
      ],
      correta: 1,
      explicacao:
        'No modelo de afiliação (*RevShare*), os influenciadores ganham comissão direta sobre o dinheiro que seus seguidores PERDEM. "Grupos de sinais" são uma farsa para gerar volume de perdas.',
    },
  ];

  const [indicePergunta, setIndicePergunta] = useState<number>(0);
  const [respostasUsuario, setRespostasUsuario] = useState<(number | null)[]>(
    new Array(perguntas.length).fill(null)
  );
  const [mostrarExplicacao, setMostrarExplicacao] = useState<boolean>(false);
  const [quizFinalizado, setQuizFinalizado] = useState<boolean>(false);

  const perguntaAtual = perguntas[indicePergunta];
  const respostaSelecionada = respostasUsuario[indicePergunta];

  const selecionarResposta = (indiceOpcao: number) => {
    if (respostaSelecionada !== null) return; // Não permite alterar após responder
    const novasRespostas = [...respostasUsuario];
    novasRespostas[indicePergunta] = indiceOpcao;
    setRespostasUsuario(novasRespostas);
    setMostrarExplicacao(true);
  };

  const proximaPergunta = () => {
    setMostrarExplicacao(false);
    if (indicePergunta < perguntas.length - 1) {
      setIndicePergunta(indicePergunta + 1);
    } else {
      setQuizFinalizado(true);
    }
  };

  const reiniciarQuiz = () => {
    setIndicePergunta(0);
    setRespostasUsuario(new Array(perguntas.length).fill(null));
    setMostrarExplicacao(false);
    setQuizFinalizado(false);
  };

  const acertos = respostasUsuario.reduce<number>((total, resp, idx) => {
    return resp === perguntas[idx].correta ? total + 1 : total;
  }, 0);

  const porcentagemAcerto = Math.round((acertos / perguntas.length) * 100);

  let tituloDiagnostico = 'Consciência em Desenvolvimento';
  let badgeColor = 'text-[#d8a13b] bg-[#d8a13b]/15 border-[#d8a13b]/30';
  let descricaoDiagnostico =
    'Você já percebe alguns riscos, mas ainda pode cair em armadilhas cognitivas e promessas de lucro fácil. Revise os conceitos do simulador!';

  if (acertos >= 5) {
    tituloDiagnostico = 'Guardião da Consciência Crítica';
    badgeColor = 'text-[#50fa7b] bg-[#50fa7b]/15 border-[#50fa7b]/30';
    descricaoDiagnostico =
      'Excelente! Você compreende com profundidade a matemática dos jogos, os mecanismos de dopamina e a importância da prevenção em saúde mental. Você está apto a multiplicar esse conhecimento!';
  } else if (acertos <= 2) {
    tituloDiagnostico = 'Vulnerável a Ilusões das Apostas';
    badgeColor = 'text-[#e4552e] bg-[#e4552e]/15 border-[#e4552e]/30';
    descricaoDiagnostico =
      'Atenção: seus resultados indicam que o marketing predatório e as falácias estatísticas ainda exercem influência. Conhecer a fundo o algoritmo é sua melhor proteção.';
  }

  return (
    <section id="quiz" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#14171b] text-[#f4f1ea] border-b border-[#23272d]">
      <div className="max-w-4xl mx-auto space-y-10">
        {/* Cabeçalho */}
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-[#d8a13b]/15 text-[#d8a13b] border border-[#d8a13b]/30 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
            <Brain className="w-3.5 h-3.5" />
            Avaliação de Consciência Crítica
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight text-[#f4f1ea]">
            Quiz do Apostador:{' '}
            <span className="text-[#e4552e]">Você Conhece a Realidade?</span>
          </h2>
          <p className="text-[#a9adb6] text-sm sm:text-base leading-relaxed">
            Responda a 6 perguntas com fundamentação matemática, neurológica e jurídica.
            Descubra seu nível de imunidade contra as táticas predatórias do jogo.
          </p>
        </div>

        {!quizFinalizado ? (
          /* CAIXA DA PERGUNTA */
          <div className="bg-[#0e1013] border-2 border-[#2b3039] rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative">
            {/* Barra de Progresso */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#d8a13b] font-bold">
                  Pergunta {indicePergunta + 1} de {perguntas.length}
                </span>
                <span className="text-[#8a8f99] uppercase tracking-wider">
                  {perguntaAtual.categoria}
                </span>
              </div>
              <div className="w-full h-2 bg-[#171b21] rounded-full overflow-hidden border border-[#23272d]">
                <div
                  className="h-full bg-[#e4552e] transition-all duration-300 rounded-full"
                  style={{
                    width: `${((indicePergunta + 1) / perguntas.length) * 100}%`,
                  }}
                ></div>
              </div>
            </div>

            {/* Enunciado */}
            <div>
              <h3 className="text-lg sm:text-xl font-extrabold text-[#f4f1ea] leading-snug">
                {perguntaAtual.enunciado}
              </h3>
            </div>

            {/* Opções de Resposta */}
            <div className="space-y-3">
              {perguntaAtual.opcoes.map((opcao, idx) => {
                const foiRespondida = respostaSelecionada !== null;
                const eCorreta = idx === perguntaAtual.correta;
                const eEscolhida = respostaSelecionada === idx;

                let classesEstilo =
                  'bg-[#14171b] border-[#252b33] text-[#c5c5c5] hover:border-[#3d4554] hover:bg-[#1a1f26]';

                if (foiRespondida) {
                  if (eCorreta) {
                    classesEstilo =
                      'bg-[#12281a] border-[#2e7d5b] text-[#50fa7b] font-semibold';
                  } else if (eEscolhida && !eCorreta) {
                    classesEstilo =
                      'bg-[#281515] border-[#e4552e] text-[#ff8e7b] font-semibold';
                  } else {
                    classesEstilo =
                      'bg-[#0e1013] border-[#1d2127] text-[#5c616b] opacity-60';
                  }
                }

                return (
                  <button
                    key={idx}
                    onClick={() => selecionarResposta(idx)}
                    disabled={foiRespondida}
                    className={`w-full p-4 rounded-2xl border text-left text-xs sm:text-sm transition-all flex items-start justify-between gap-3 cursor-pointer disabled:cursor-default ${classesEstilo}`}
                  >
                    <div className="flex items-start gap-3">
                      <span className="w-6 h-6 rounded-lg bg-[#23272d] text-[#f4f1ea] text-xs font-mono font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{opcao}</span>
                    </div>

                    {foiRespondida && (
                      <div className="flex-shrink-0 mt-0.5">
                        {eCorreta && (
                          <CheckCircle2 className="w-5 h-5 text-[#50fa7b]" />
                        )}
                        {eEscolhida && !eCorreta && (
                          <XCircle className="w-5 h-5 text-[#e4552e]" />
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Painel de Explicação Científica Imediata */}
            {mostrarExplicacao && (
              <div className="p-5 rounded-2xl bg-[#171b21] border border-[#2d323a] space-y-3 animate-fadeIn">
                <div className="flex items-center gap-2">
                  {respostaSelecionada === perguntaAtual.correta ? (
                    <span className="text-xs font-bold uppercase text-[#50fa7b] flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> Resposta Correta!
                    </span>
                  ) : (
                    <span className="text-xs font-bold uppercase text-[#e4552e] flex items-center gap-1">
                      <XCircle className="w-4 h-4" /> Resposta Incorreta
                    </span>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-[#c5c5c5] leading-relaxed">
                  {perguntaAtual.explicacao}
                </p>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={proximaPergunta}
                    className="inline-flex items-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] text-white px-5 py-2.5 rounded-full font-bold text-xs uppercase tracking-wider transition cursor-pointer"
                  >
                    <span>
                      {indicePergunta < perguntas.length - 1
                        ? 'Próxima Pergunta'
                        : 'Ver Meu Diagnóstico'}
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          /* RESULTADO FINAL DO QUIZ */
          <div className="bg-[#0e1013] border-2 border-[#34373b] rounded-3xl p-6 sm:p-10 space-y-8 shadow-2xl text-center animate-fadeIn">
            <div className="w-16 h-16 rounded-2xl bg-[#d8a13b]/20 text-[#d8a13b] flex items-center justify-center mx-auto shadow-inner">
              <Award className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className={`inline-block px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest border ${badgeColor}`}>
                {tituloDiagnostico}
              </span>
              <h3 className="text-3xl sm:text-4xl font-black uppercase text-[#f4f1ea]">
                Você acertou {acertos} de {perguntas.length} ({porcentagemAcerto}%)
              </h3>
              <p className="text-sm sm:text-base text-[#a9adb6] max-w-xl mx-auto leading-relaxed pt-2">
                {descricaoDiagnostico}
              </p>
            </div>

            {/* Certificado de Conscientização ExpoCEEP */}
            <div className="bg-[#14171b] border-2 border-dashed border-[#d8a13b]/40 rounded-2xl p-6 max-w-lg mx-auto text-left space-y-3">
              <div className="flex items-center justify-between border-b border-[#23272d] pb-2">
                <span className="text-[10px] font-mono text-[#d8a13b] uppercase font-bold">
                  Comprovante de Conhecimento • ExpoCEEP
                </span>
                <span className="text-[10px] text-[#8a8f99]">TCC Turma 3M</span>
              </div>
              <p className="text-xs text-[#f4f1ea] font-serif leading-relaxed">
                "Certificamos que o visitante completou a trilha avaliativa do projeto <strong>Brasil Contra Bets: Da Proibição à Prevenção</strong>, demonstrando discernimento sobre algoritmos predatórios e a importância da proteção em saúde mental."
              </p>
              <div className="flex items-center justify-between pt-1 text-[11px] text-[#8a8f99] font-mono">
                <span>Data: {new Date().toLocaleDateString('pt-BR')}</span>
                <span className="text-[#50fa7b] font-bold">Status: Aprovado</span>
              </div>
            </div>

            {/* Ações */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={reiniciarQuiz}
                className="inline-flex items-center gap-2 bg-[#1f242c] hover:bg-[#282f3a] text-[#f4f1ea] px-6 py-3 rounded-full text-xs font-bold uppercase tracking-wider border border-[#34373b] transition cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-[#d8a13b]" />
                Refazer o Quiz
              </button>

              <a
                href="#pesquisa"
                className="inline-flex items-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] text-white px-6 py-3 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer shadow"
              >
                <Sparkles className="w-4 h-4" />
                Votar na Pesquisa ExpoCEEP
              </a>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
