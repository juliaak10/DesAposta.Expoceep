import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [aberto, setAberto] = useState<number | null>(0);

  const faqs = [
    {
      pergunta: 'Apostar pouco dinheiro também pode ser um problema?',
      resposta:
        'Sim. A gravidade da dependência não é medida apenas pelo montante apostado, mas pela frequência, obsessão psicológica, perda de controle de tempo e incapacidade de parar mesmo diante de prejuízos recorrentes.',
    },
    {
      pergunta: 'É possível parar de apostar e retomar o controle?',
      resposta:
        'Com certeza. Milhares de pessoas superam o transtorno do jogo todos os anos. O processo envolve acolhimento psicológico, reorganização das rotinas financeiras, apoio da família e eliminação de gatilhos visuais e digitais.',
    },
    {
      pergunta: 'Onde posso procurar atendimento e acolhimento gratuito?',
      resposta:
        'O Sistema Único de Saúde (SUS) oferece acolhimento gratuito e especializado nos Centros de Atenção Psicossocial (CAPS) em todo o Brasil. Você também pode acionar o Disque Saúde pelo 136 ou o CVV pelo número 188 para suporte emergencial.',
    },
    {
      pergunta: 'Por que o CPF é solicitado no formulário da petição?',
      resposta:
        'O CPF é exigido como chave de unicidade para garantir a legitimidade do abaixo-assinado público e impedir que a mesma pessoa assine repetidas vezes. No banco de dados, os dados sensíveis são protegidos e no mural público são exibidos apenas com máscara de proteção (ex: ***.123.***-**).',
    },
    {
      pergunta: 'Como funciona a estrutura de banco de dados do projeto CEEP Contra as BETS?',
      resposta:
        'A plataforma utiliza uma modelagem relacional 1:N no SQLite. A tabela pai "categorias" armazena os motivos padronizados (Impacto Financeiro, Saúde Mental, Regulamentação), enquanto a tabela filho "assinaturas" guarda os registros vinculados através da chave estrangeira (FK categoria_id).',
    },
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#14171b] text-[#f4f1ea] border-b border-[#23272d]" id="faq">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-[#d8a13b] uppercase text-xs font-extrabold tracking-widest inline-flex items-center gap-1.5 mb-2">
            <HelpCircle className="w-4 h-4" /> Perguntas Frequentes
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold uppercase tracking-tight text-[#f4f1ea]">
            Dúvidas Comuns
          </h2>
          <p className="text-[#a9adb6] text-base mt-2">
            Informação fundamentada é o mecanismo mais eficiente de proteção individual e coletiva.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isAberto = aberto === index;
            return (
              <div
                key={index}
                className="bg-[#0e1013] border border-[#34373b] rounded-2xl overflow-hidden transition-all duration-200"
              >
                <button
                  onClick={() => setAberto(isAberto ? null : index)}
                  className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 focus:outline-none cursor-pointer"
                >
                  <span className="font-bold text-base sm:text-lg text-[#d8a13b]">
                    {faq.pergunta}
                  </span>
                  <span className="p-1 rounded-full bg-[#1c2027] text-[#c5c5c5] flex-shrink-0">
                    {isAberto ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </span>
                </button>

                {isAberto && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-sm sm:text-base text-[#c5c5c5] leading-relaxed border-t border-[#23272d]/60 animate-fadeIn">
                    {faq.resposta}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
