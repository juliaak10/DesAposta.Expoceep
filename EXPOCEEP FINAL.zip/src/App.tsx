import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { HeroForm } from './components/HeroForm.tsx';
import { ProblemCards } from './components/ProblemCards.tsx';
import { AfterProhibitionSection } from './components/AfterProhibitionSection.tsx';
import { SimulatorSection } from './components/SimulatorSection.tsx';
import { QuizSection } from './components/QuizSection.tsx';
import { MythsTruthsSection } from './components/MythsTruthsSection.tsx';
import { SurveySection } from './components/SurveySection.tsx';
import { DataVisualizationSection } from './components/DataVisualizationSection.tsx';
import { WarningSigns } from './components/WarningSigns.tsx';
import { HelpSection } from './components/HelpSection.tsx';
import { SignaturesMural } from './components/SignaturesMural.tsx';
import { FaqSection } from './components/FaqSection.tsx';
import { AboutProjectSection } from './components/AboutProjectSection.tsx';
import { DatabaseInspectorModal } from './components/DatabaseInspectorModal.tsx';
import { Footer } from './components/Footer.tsx';
import { Categoria, Assinatura, EstatisticaCategoria, PesquisaEstatisticas } from './types.ts';
import { ArrowRight, CheckCircle2, ShieldAlert } from 'lucide-react';

export default function App() {
  const [categorias, setCategorias] = useState<Categoria[]>([
    { id: 1, nome_alerta: 'Impacto Financeiro' },
    { id: 2, nome_alerta: 'Saúde Mental' },
    { id: 3, nome_alerta: 'Regulamentação' },
  ]);
  const [assinaturas, setAssinaturas] = useState<Assinatura[]>([]);
  const [estatisticas, setEstatisticas] = useState<EstatisticaCategoria[]>([]);
  const [totalAssinaturas, setTotalAssinaturas] = useState<number>(0);
  const [estatisticasPesquisa, setEstatisticasPesquisa] = useState<PesquisaEstatisticas | null>(null);
  const [isDbModalOpen, setIsDbModalOpen] = useState(false);

  // Carregar dados de assinaturas, categorias e pesquisa do SQLite
  const carregarDados = async () => {
    try {
      // 1. Categorias
      const resCat = await fetch('/api/categorias');
      if (resCat.ok) {
        const dataCat = await resCat.json();
        if (dataCat.categorias && dataCat.categorias.length > 0) {
          setCategorias(dataCat.categorias);
        }
      }

      // 2. Assinaturas e Estatísticas da Petição (1:N)
      const resAss = await fetch('/api/assinaturas');
      if (resAss.ok) {
        const dataAss = await resAss.json();
        setAssinaturas(dataAss.assinaturas || []);
        setEstatisticas(dataAss.estatisticas || []);
        setTotalAssinaturas(dataAss.total || 0);
      }

      // 3. Estatísticas da Pesquisa ExpoCEEP
      const resPesq = await fetch('/api/pesquisa');
      if (resPesq.ok) {
        const dataPesq = await resPesq.json();
        setEstatisticasPesquisa(dataPesq);
      }
    } catch (err) {
      console.error('Erro ao buscar dados do servidor SQLite:', err);
    }
  };

  useEffect(() => {
    carregarDados();
  }, []);

  return (
    <div className="min-h-screen bg-[#0e1013] text-[#1c1d20] flex flex-col font-sans selection:bg-[#e4552e] selection:text-white">
      {/* 1. Barra de Navegação Expandida */}
      <Navbar
        onOpenDatabase={() => setIsDbModalOpen(true)}
        totalAssinaturas={totalAssinaturas}
      />

      <main className="flex-1">
        {/* 2. Seção Inicial com Pergunta Central e Formulário Conectado ao SQLite */}
        <HeroForm
          categorias={categorias}
          totalAssinaturas={totalAssinaturas}
          onAssinaturaCadastrada={carregarDados}
          onOpenDatabase={() => setIsDbModalOpen(true)}
        />

        {/* 3. O Problema (Impactos e Alertas) */}
        <ProblemCards />

        {/* 4. Depois da Proibição (Análise Científica do Cenário Atual) */}
        <AfterProhibitionSection />

        {/* 5. Simulador Interativo: "Desafio dos R$ 100" */}
        <SimulatorSection />

        {/* 6. Quiz Científico do Apostador */}
        <QuizSection />

        {/* 7. Mitos e Verdades (Ciência contra o Marketing) */}
        <MythsTruthsSection />

        {/* 8. Pesquisa ExpoCEEP (Enquete Sociológica com Persistência SQLite) */}
        <SurveySection
          estatisticasPesquisa={estatisticasPesquisa}
          onRespostaEnviada={carregarDados}
        />

        {/* 9. Central de Dados & Estatísticas (Petição 1:N + Pesquisa + Teorema da Ruína) */}
        <DataVisualizationSection
          estatisticasAssinaturas={estatisticas}
          totalAssinaturas={totalAssinaturas}
          estatisticasPesquisa={estatisticasPesquisa}
          onOpenDatabase={() => setIsDbModalOpen(true)}
        />

        {/* 10. Sinais de Alerta Comportamentais */}
        <WarningSigns />

        {/* 11. Onde Buscar Ajuda & Recursos de Saúde Mental */}
        <HelpSection />

        {/* 12. Mural Público de Assinaturas & Apoiadores */}
        <SignaturesMural assinaturas={assinaturas} categorias={categorias} />

        {/* 13. Perguntas Frequentes (FAQ) */}
        <FaqSection />

        {/* 14. Sobre o Projeto (Ficha Acadêmica ExpoCEEP • Turma 3M) */}
        <AboutProjectSection onOpenDatabase={() => setIsDbModalOpen(true)} />

        {/* Chamada Final para Ação Coletiva */}
        <section className="bg-[#08090b] text-[#f4f1ea] text-center py-20 px-4 sm:px-6 lg:px-8 border-b border-[#23272d]">
          <div className="max-w-3xl mx-auto space-y-6">
            <span className="text-[#d8a13b] uppercase text-xs font-black tracking-widest block">
              Movimento Brasil Contra as Bets
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black uppercase tracking-tight">
              Sua vida e seu futuro valem mais do que qualquer aposta.
            </h2>
            <p className="text-[#a9adb6] text-base sm:text-lg max-w-xl mx-auto leading-relaxed">
              Ajude a fortalecer a prevenção e a educação nas escolas e comunidades.
              Conhecimento e acolhimento salvam vidas.
            </p>
            <div className="pt-2 flex flex-wrap justify-center gap-4">
              <a
                href="#assinar"
                className="inline-flex items-center gap-2 bg-[#e4552e] hover:bg-[#b8431f] text-white px-8 py-4 rounded-full font-black text-xs uppercase tracking-wider transition-all shadow-xl hover:shadow-orange-950/50 cursor-pointer"
              >
                <CheckCircle2 className="w-5 h-5" />
                Assinar o Movimento Agora
              </a>
              <button
                onClick={() => setIsDbModalOpen(true)}
                className="inline-flex items-center gap-2 bg-[#1a1e24] hover:bg-[#252b33] text-[#d8a13b] border border-[#3b3f46] px-6 py-4 rounded-full font-bold text-xs uppercase tracking-wider transition-all cursor-pointer"
              >
                Inspecionar Banco SQLite (DER)
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Rodapé com Créditos Completos */}
      <Footer onOpenDatabase={() => setIsDbModalOpen(true)} />

      {/* Modal do Banco de Dados SQLite & DER */}
      <DatabaseInspectorModal
        isOpen={isDbModalOpen}
        onClose={() => setIsDbModalOpen(false)}
        onRefresh={carregarDados}
      />
    </div>
  );
}
