// Utilitários de formatação e validação de CPF (Validação de unicidade e algoritmo)

export function formatarCpf(valor: string): string {
  const digitos = valor.replace(/\D/g, '').slice(0, 11);
  if (digitos.length <= 3) return digitos;
  if (digitos.length <= 6) return `${digitos.slice(0, 3)}.${digitos.slice(3)}`;
  if (digitos.length <= 9) return `${digitos.slice(0, 3)}.${digitos.slice(3, 6)}.${digitos.slice(6)}`;
  return `${digitos.slice(0, 3)}.${digitos.slice(3, 6)}.${digitos.slice(6, 9)}-${digitos.slice(9, 11)}`;
}

export function validarCpf(cpf: string): { valido: boolean; motivo?: string } {
  const limpo = cpf.replace(/\D/g, '');

  if (limpo.length !== 11) {
    return { valido: false, motivo: 'O CPF deve conter exatamente 11 dígitos numéricos.' };
  }

  // Verificar dígitos repetidos conhecidos (ex: 111.111.111-11)
  if (/^(\d)\1{10}$/.test(limpo)) {
    return { valido: false, motivo: 'CPF com todos os dígitos iguais não é aceito.' };
  }

  // Cálculo do primeiro dígito verificador
  let soma = 0;
  for (let i = 0; i < 9; i++) {
    soma += parseInt(limpo.charAt(i), 10) * (10 - i);
  }
  let resto = 11 - (soma % 11);
  let digito1 = resto === 10 || resto === 11 ? 0 : resto;
  if (digito1 !== parseInt(limpo.charAt(9), 10)) {
    return { valido: false, motivo: 'Dígito verificador do CPF inválido.' };
  }

  // Cálculo do segundo dígito verificador
  soma = 0;
  for (let i = 0; i < 10; i++) {
    soma += parseInt(limpo.charAt(i), 10) * (11 - i);
  }
  resto = 11 - (soma % 11);
  let digito2 = resto === 10 || resto === 11 ? 0 : resto;
  if (digito2 !== parseInt(limpo.charAt(10), 10)) {
    return { valido: false, motivo: 'Dígito verificador do CPF inválido.' };
  }

  return { valido: true };
}
