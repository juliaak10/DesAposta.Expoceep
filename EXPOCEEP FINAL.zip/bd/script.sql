-- ==========================================================
-- PROJETO: CEEP Contra as BETS (Petição Pública)
-- EQUIPE: Gabriely Martins Cabral, Julia Augusta do Espírito Santo Nicolack e Rafael Bertoldo Varela
-- TURMA: 3M - Desenvolvimento de Sistemas
-- ARQUIVO: bd/script.sql
-- ==========================================================

-- Tabela 1: Categorias de Alerta/Motivações da Petição
-- Lado (1) da cardinalidade 1:N
CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_alerta TEXT NOT NULL UNIQUE
);

-- Tabela 2: Registro de Assinaturas da Petição Pública
-- Lado (N) da cardinalidade 1:N, recebe a Foreign Key
CREATE TABLE IF NOT EXISTS assinaturas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_completo TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE, -- Garante uma assinatura por e-mail
    cpf TEXT NOT NULL UNIQUE,   -- Validação de unicidade do apoiador
    comentario TEXT,            -- Depoimento opcional
    data_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    categoria_id INTEGER NOT NULL, -- Chave Estrangeira (FK)
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Tabela 3: Enquete Científica da ExpoCEEP (Percepção sobre Apostas e Prevenção)
CREATE TABLE IF NOT EXISTS pesquisa_respostas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    faixa_etaria TEXT NOT NULL,
    contato_apostas TEXT NOT NULL,
    proibicao_suficiente TEXT NOT NULL,
    area_prioritaria TEXT NOT NULL,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Inserção de Categorias Padrão (Conforme especificado no Guia de Execução - Etapa 1)
INSERT OR IGNORE INTO categorias (id, nome_alerta) VALUES 
(1, 'Impacto Financeiro'),
(2, 'Saúde Mental'),
(3, 'Regulamentação');

-- Amostras iniciais da Pesquisa de Percepção ExpoCEEP
INSERT OR IGNORE INTO pesquisa_respostas (id, faixa_etaria, contato_apostas, proibicao_suficiente, area_prioritaria, criado_em) VALUES
(1, '18-24 anos', 'Conheço amigos/parentes endividados', 'Não, migrou para sites clandestinos', 'Educação financeira e prevenção nas escolas', '2026-03-20 11:00:00'),
(2, 'Menor de 18 anos', 'Já apostei ou tive curiosidade', 'Não, falta suporte à saúde mental', 'Educação financeira e prevenção nas escolas', '2026-03-20 11:30:00'),
(3, '25-39 anos', 'Já tive prejuízo financeiro relevante', 'Não, migrou para sites clandestinos', 'Centros de acolhimento e terapia pelo SUS', '2026-03-21 14:15:00'),
(4, '40 anos ou mais', 'Conheço amigos/parentes endividados', 'Não, migrou para sites clandestinos', 'Apoio e renegociação para famílias endividadas', '2026-03-21 15:40:00'),
(5, '18-24 anos', 'Nunca apostei', 'Não, falta suporte à saúde mental', 'Bloqueio técnico rigoroso de plataformas ilegais', '2026-03-22 09:10:00');

