import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

let dbInstance: Database | null = null;
const dbDir = path.join(process.cwd(), 'bd');
const dbPath = path.join(dbDir, 'peticao.db');
const sqlScriptPath = path.join(dbDir, 'script.sql');

export async function getDatabase(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  const SQL = await initSqlJs();

  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  if (fs.existsSync(dbPath)) {
    try {
      const fileBuffer = fs.readFileSync(dbPath);
      dbInstance = new SQL.Database(fileBuffer);
      dbInstance.run('PRAGMA foreign_keys = ON;');
    } catch (err) {
      console.error('Erro ao ler banco existente, recriando...', err);
      dbInstance = new SQL.Database();
    }
  } else {
    dbInstance = new SQL.Database();
  }

  // Executar DDL do script.sql para garantir integridade e tabelas
  if (fs.existsSync(sqlScriptPath)) {
    const scriptContent = fs.readFileSync(sqlScriptPath, 'utf-8');
    dbInstance.run(scriptContent);
  } else {
    dbInstance.run(`
      CREATE TABLE IF NOT EXISTS categorias (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome_alerta TEXT NOT NULL UNIQUE
      );

      CREATE TABLE IF NOT EXISTS assinaturas (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          nome_completo TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          cpf TEXT NOT NULL UNIQUE,
          comentario TEXT,
          data_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
          categoria_id INTEGER NOT NULL,
          FOREIGN KEY (categoria_id) REFERENCES categorias(id)
      );

      INSERT OR IGNORE INTO categorias (id, nome_alerta) VALUES 
      (1, 'Impacto Financeiro'),
      (2, 'Saúde Mental'),
      (3, 'Regulamentação');
    `);
  }

  // Verificar se existem dados em categorias
  const catCheck = dbInstance.exec('SELECT COUNT(*) as cnt FROM categorias');
  const catCount = catCheck.length > 0 && catCheck[0].values.length > 0 ? (catCheck[0].values[0][0] as number) : 0;
  if (catCount === 0) {
    dbInstance.run(`
      INSERT INTO categorias (id, nome_alerta) VALUES 
      (1, 'Impacto Financeiro'),
      (2, 'Saúde Mental'),
      (3, 'Regulamentação');
    `);
  }

  // Se a tabela de assinaturas estiver vazia, inserir os exemplos do PDF (Página 6)
  const assCheck = dbInstance.exec('SELECT COUNT(*) as cnt FROM assinaturas');
  const assCount = assCheck.length > 0 && assCheck[0].values.length > 0 ? (assCheck[0].values[0][0] as number) : 0;
  if (assCount === 0) {
    dbInstance.run(`
      INSERT INTO assinaturas (id, nome_completo, email, cpf, comentario, categoria_id, data_registro) VALUES
      (101, 'Ana Silva', 'ana@email.com', '123.456.789-01', 'Perdi amigos para o vício em apostas. Precisamos de controle urgente e apoio psicológico!', 2, '2026-03-10 10:15:00'),
      (102, 'Bruno Souza', 'bruno@email.com', '234.567.890-12', 'O salário de muitas famílias é drenado no começo do mês. As perdas financeiras são devastadoras.', 1, '2026-03-11 14:30:00'),
      (103, 'Carlos Lima', 'carlos@email.com', '345.678.901-23', 'A publicidade agressiva engana os jovens com promessas de dinheiro fácil. Apoio total à petição!', 2, '2026-03-12 09:20:00'),
      (104, 'Mariana Ferreira', 'mariana.f@email.com', '456.789.012-34', 'Proibir a propaganda invasiva em redes sociais e transmissões esportivas é urgente.', 3, '2026-03-13 16:45:00');
    `);
  }

  // Verificar se a tabela pesquisa_respostas existe e tem dados
  dbInstance.run(`
    CREATE TABLE IF NOT EXISTS pesquisa_respostas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        faixa_etaria TEXT NOT NULL,
        contato_apostas TEXT NOT NULL,
        proibicao_suficiente TEXT NOT NULL,
        area_prioritaria TEXT NOT NULL,
        criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const pesqCheck = dbInstance.exec('SELECT COUNT(*) as cnt FROM pesquisa_respostas');
  const pesqCount = pesqCheck.length > 0 && pesqCheck[0].values.length > 0 ? (pesqCheck[0].values[0][0] as number) : 0;
  if (pesqCount === 0) {
    dbInstance.run(`
      INSERT INTO pesquisa_respostas (id, faixa_etaria, contato_apostas, proibicao_suficiente, area_prioritaria, criado_em) VALUES
      (1, '18-24 anos', 'Conheço amigos/parentes endividados', 'Não, migrou para sites clandestinos', 'Educação financeira e prevenção nas escolas', '2026-03-20 11:00:00'),
      (2, 'Menor de 18 anos', 'Já apostei ou tive curiosidade', 'Não, falta suporte à saúde mental', 'Educação financeira e prevenção nas escolas', '2026-03-20 11:30:00'),
      (3, '25-39 anos', 'Já tive prejuízo financeiro relevante', 'Não, migrou para sites clandestinos', 'Centros de acolhimento e terapia pelo SUS', '2026-03-21 14:15:00'),
      (4, '40 anos ou mais', 'Conheço amigos/parentes endividados', 'Não, migrou para sites clandestinos', 'Apoio e renegociação para famílias endividadas', '2026-03-21 15:40:00'),
      (5, '18-24 anos', 'Nunca apostei', 'Não, falta suporte à saúde mental', 'Bloqueio técnico rigoroso de plataformas ilegais', '2026-03-22 09:10:00');
    `);
  }

  // Persistir no arquivo SQLite bd/peticao.db
  saveDatabase(dbInstance);

  return dbInstance;
}

export function saveDatabase(db: Database) {
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  } catch (err) {
    console.error('Erro ao persistir banco de dados em disco:', err);
  }
}

export interface Categoria {
  id: number;
  nome_alerta: string;
}

export interface Assinatura {
  id: number;
  nome_completo: string;
  nome_publico?: string;
  email: string;
  cpf: string;
  cpf_mascarado?: string;
  comentario: string | null;
  data_registro: string;
  categoria_id: number;
  categoria_nome?: string;
}

export interface EstatisticaCategoria {
  categoria_id: number;
  nome_alerta: string;
  total: number;
  porcentagem: number;
}

// Obter categorias cadastradas
export async function getCategorias(): Promise<Categoria[]> {
  const db = await getDatabase();
  const res = db.exec('SELECT id, nome_alerta FROM categorias ORDER BY id ASC');
  if (res.length === 0) return [];
  return res[0].values.map((v) => ({
    id: v[0] as number,
    nome_alerta: v[1] as string,
  }));
}

// Obter lista de assinaturas com JOIN em categorias (1:N)
export async function getAssinaturas(): Promise<{
  total: number;
  assinaturas: Assinatura[];
  estatisticas: EstatisticaCategoria[];
}> {
  const db = await getDatabase();
  const query = `
    SELECT 
      a.id, 
      a.nome_completo, 
      a.email, 
      a.cpf, 
      a.comentario, 
      a.data_registro, 
      a.categoria_id,
      c.nome_alerta as categoria_nome
    FROM assinaturas a
    JOIN categorias c ON a.categoria_id = c.id
    ORDER BY a.id DESC
  `;
  const res = db.exec(query);
  const assinaturas: Assinatura[] = [];

  if (res.length > 0) {
    for (const row of res[0].values) {
      const nomeCompleto = String(row[1] || '');
      const partes = nomeCompleto.trim().split(/\s+/);
      const primeiro = partes[0] || '';
      const ultimo = partes.length > 1 ? partes[partes.length - 1][0] + '.' : '';
      const nomePublico = `${primeiro} ${ultimo}`.trim();

      const cpfStr = String(row[3] || '');
      const cpfDigits = cpfStr.replace(/\D/g, '');
      const cpfMascarado =
        cpfDigits.length >= 6
          ? `***.${cpfDigits.substring(3, 6)}.***-**`
          : '***.***.***-**';

      assinaturas.push({
        id: Number(row[0]),
        nome_completo: nomeCompleto,
        nome_publico: nomePublico,
        email: String(row[2] || ''),
        cpf: cpfStr,
        cpf_mascarado: cpfMascarado,
        comentario: row[4] ? String(row[4]) : null,
        data_registro: String(row[5] || ''),
        categoria_id: Number(row[6]),
        categoria_nome: String(row[7] || ''),
      });
    }
  }

  // Calcular estatísticas por categoria
  const categorias = await getCategorias();
  const totalGeral = assinaturas.length;

  const statsRes = db.exec(`
    SELECT c.id, c.nome_alerta, COUNT(a.id) as total
    FROM categorias c
    LEFT JOIN assinaturas a ON c.id = a.categoria_id
    GROUP BY c.id, c.nome_alerta
    ORDER BY c.id ASC
  `);

  const estatisticas: EstatisticaCategoria[] = [];
  if (statsRes.length > 0) {
    for (const r of statsRes[0].values) {
      const total = Number(r[2] || 0);
      estatisticas.push({
        categoria_id: Number(r[0]),
        nome_alerta: String(r[1]),
        total,
        porcentagem: totalGeral > 0 ? Math.round((total / totalGeral) * 100) : 0,
      });
    }
  } else {
    for (const c of categorias) {
      estatisticas.push({
        categoria_id: c.id,
        nome_alerta: c.nome_alerta,
        total: 0,
        porcentagem: 0,
      });
    }
  }

  return {
    total: totalGeral,
    assinaturas,
    estatisticas,
  };
}

// Inserir nova assinatura respeitando as constraints de integridade
export async function cadastrarAssinatura(data: {
  nome_completo: string;
  email: string;
  cpf: string;
  categoria_id: number;
  comentario?: string;
}): Promise<{ sucesso: boolean; mensagem: string; id?: number }> {
  const db = await getDatabase();

  const nome = (data.nome_completo || '').trim();
  const email = (data.email || '').trim().toLowerCase();
  const rawCpf = (data.cpf || '').trim();
  const cpfDigits = rawCpf.replace(/\D/g, '');
  const categoriaId = Number(data.categoria_id);
  const comentario = data.comentario ? data.comentario.trim() : null;

  if (!nome || !email || !rawCpf || !categoriaId) {
    return {
      sucesso: false,
      mensagem: 'Por favor, preencha todos os campos obrigatórios (Nome, E-mail, CPF e Motivo de Alerta).',
    };
  }

  if (cpfDigits.length !== 11) {
    return {
      sucesso: false,
      mensagem: 'CPF inválido. O CPF deve conter exatamente 11 dígitos numéricos.',
    };
  }

  // Formatar CPF padronizado: 000.000.000-00
  const cpfFormatado = `${cpfDigits.slice(0, 3)}.${cpfDigits.slice(3, 6)}.${cpfDigits.slice(6, 9)}-${cpfDigits.slice(9, 11)}`;

  // Validação de unicidade no banco de dados SQLite
  const emailCheck = db.exec(`SELECT id FROM assinaturas WHERE LOWER(email) = '${email.replace(/'/g, "''")}'`);
  if (emailCheck.length > 0 && emailCheck[0].values.length > 0) {
    return {
      sucesso: false,
      mensagem: 'Este e-mail já foi utilizado para assinar a petição pública.',
    };
  }

  const cpfCheck = db.exec(
    `SELECT id FROM assinaturas WHERE cpf = '${cpfFormatado.replace(/'/g, "''")}' OR cpf = '${cpfDigits.replace(/'/g, "''")}'`
  );
  if (cpfCheck.length > 0 && cpfCheck[0].values.length > 0) {
    return {
      sucesso: false,
      mensagem: 'Este CPF já consta como apoiador da petição pública.',
    };
  }

  // Verificar se a categoria existe (relação 1:N)
  const catCheck = db.exec(`SELECT id FROM categorias WHERE id = ${categoriaId}`);
  if (catCheck.length === 0 || catCheck[0].values.length === 0) {
    return {
      sucesso: false,
      mensagem: 'A categoria de alerta informada não existe no banco de dados.',
    };
  }

  try {
    const safeComentario = comentario ? `'${comentario.replace(/'/g, "''")}'` : 'NULL';
    const insertSql = `
      INSERT INTO assinaturas (nome_completo, email, cpf, comentario, categoria_id)
      VALUES (
        '${nome.replace(/'/g, "''")}',
        '${email.replace(/'/g, "''")}',
        '${cpfFormatado}',
        ${safeComentario},
        ${categoriaId}
      );
    `;
    db.run(insertSql);

    const lastIdRes = db.exec('SELECT last_insert_rowid()');
    const novoId = lastIdRes.length > 0 ? Number(lastIdRes[0].values[0][0]) : undefined;

    // Salvar em bd/peticao.db
    saveDatabase(db);

    return {
      sucesso: true,
      mensagem: 'Assinatura confirmada e gravada com sucesso no banco de dados SQLite!',
      id: novoId,
    };
  } catch (err: any) {
    console.error('Erro ao inserir assinatura:', err);
    return {
      sucesso: false,
      mensagem: `Erro no banco de dados: ${err?.message || 'Falha ao registrar assinatura.'}`,
    };
  }
}

export interface PesquisaRespostaItem {
  id: number;
  faixa_etaria: string;
  contato_apostas: string;
  proibicao_suficiente: string;
  area_prioritaria: string;
  criado_em: string;
}

// Inserir nova resposta na enquete ExpoCEEP
export async function cadastrarRespostaPesquisa(data: {
  faixa_etaria: string;
  contato_apostas: string;
  proibicao_suficiente: string;
  area_prioritaria: string;
}): Promise<{ sucesso: boolean; mensagem: string; id?: number }> {
  const db = await getDatabase();

  const faixa = (data.faixa_etaria || '').trim();
  const contato = (data.contato_apostas || '').trim();
  const proibicao = (data.proibicao_suficiente || '').trim();
  const area = (data.area_prioritaria || '').trim();

  if (!faixa || !contato || !proibicao || !area) {
    return {
      sucesso: false,
      mensagem: 'Por favor, responda a todas as 4 perguntas da pesquisa.',
    };
  }

  try {
    const insertSql = `
      INSERT INTO pesquisa_respostas (faixa_etaria, contato_apostas, proibicao_suficiente, area_prioritaria)
      VALUES (
        '${faixa.replace(/'/g, "''")}',
        '${contato.replace(/'/g, "''")}',
        '${proibicao.replace(/'/g, "''")}',
        '${area.replace(/'/g, "''")}'
      );
    `;
    db.run(insertSql);

    const lastIdRes = db.exec('SELECT last_insert_rowid()');
    const novoId = lastIdRes.length > 0 ? Number(lastIdRes[0].values[0][0]) : undefined;

    saveDatabase(db);

    return {
      sucesso: true,
      mensagem: 'Sua contribuição para a pesquisa ExpoCEEP foi registrada com sucesso!',
      id: novoId,
    };
  } catch (err: any) {
    console.error('Erro ao cadastrar resposta da pesquisa:', err);
    return {
      sucesso: false,
      mensagem: `Erro ao gravar no banco de dados: ${err?.message}`,
    };
  }
}

// Obter estatísticas agregadas da pesquisa ExpoCEEP
export async function getEstatisticasPesquisa() {
  const db = await getDatabase();

  const resAll = db.exec('SELECT id, faixa_etaria, contato_apostas, proibicao_suficiente, area_prioritaria, criado_em FROM pesquisa_respostas ORDER BY id DESC');
  
  const total = resAll.length > 0 ? resAll[0].values.length : 0;
  const porFaixaEtaria: Record<string, number> = {};
  const porContato: Record<string, number> = {};
  const porProibicao: Record<string, number> = {};
  const porAreaPrioritaria: Record<string, number> = {};
  const respostasRecentes: PesquisaRespostaItem[] = [];

  if (resAll.length > 0) {
    for (let i = 0; i < resAll[0].values.length; i++) {
      const row = resAll[0].values[i];
      const id = Number(row[0]);
      const faixa = String(row[1]);
      const contato = String(row[2]);
      const proib = String(row[3]);
      const area = String(row[4]);
      const criado = String(row[5]);

      porFaixaEtaria[faixa] = (porFaixaEtaria[faixa] || 0) + 1;
      porContato[contato] = (porContato[contato] || 0) + 1;
      porProibicao[proib] = (porProibicao[proib] || 0) + 1;
      porAreaPrioritaria[area] = (porAreaPrioritaria[area] || 0) + 1;

      if (i < 10) {
        respostasRecentes.push({
          id,
          faixa_etaria: faixa,
          contato_apostas: contato,
          proibicao_suficiente: proib,
          area_prioritaria: area,
          criado_em: criado,
        });
      }
    }
  }

  return {
    total,
    porFaixaEtaria,
    porContato,
    porProibicao,
    porAreaPrioritaria,
    respostasRecentes,
  };
}

// Retornar informações cruas das tabelas para o Inspetor de Banco de Dados
export async function getDbInspection() {
  const db = await getDatabase();
  const tables = ['categorias', 'assinaturas', 'pesquisa_respostas'];
  const data: Record<string, { columns: string[]; rows: any[][] }> = {};

  for (const table of tables) {
    const res = db.exec(`SELECT * FROM ${table} ORDER BY id ASC`);
    if (res.length > 0) {
      data[table] = {
        columns: res[0].columns,
        rows: res[0].values,
      };
    } else {
      data[table] = {
        columns: [],
        rows: [],
      };
    }
  }

  return data;
}
